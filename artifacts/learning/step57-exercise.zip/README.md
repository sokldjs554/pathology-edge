# STEP57 LocalResidualHead

Edit only learner_refinement.py __init__ and forward after the provided guard.
Contract: conv1 1→8, conv2 8→1, both Conv2d kernel3/stride1/padding1/zeros/bias. ReLU between, add original raw logits. Zero conv2 weights and bias initially. 153 trainable parameters. No sigmoid/threshold/detach/in-place input writes.
Input/output: finite floating nonempty B1HW, same shape/device/dtype.
Run from repository root: python -m pytest -q work/step57-refinement/test_local_refinement.py
13 tests. NotImplementedError is expected until the two bodies are implemented. This is not a training command.
Source guide: docs/STEP_57.md. No reference solution is included.
