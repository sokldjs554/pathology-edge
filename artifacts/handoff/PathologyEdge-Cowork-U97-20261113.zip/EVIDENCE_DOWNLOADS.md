# 큰 원본 증거 ZIP

전달 ZIP의 용량을 줄이기 위해 아래 원본 묶음은 포함하지 않고 고정 커밋의 직접 다운로드를 연결했습니다. 사용자 제출 원본과 개발 환경 실행을 구분합니다. 각 원본 ZIP의 CRC와 SHA를 포장 시 확인했습니다. 원자료·모델 라이선스 조건을 유지하세요.

## NuCLS 선행15시야 및 전체51쌍 원자료·모델

[ZIP 다운로드](https://raw.githubusercontent.com/sokldjs554/pathology-edge/dced5d0cfaee955015f0ece599bb29ce808ccc1f/artifacts/experiments/nucls-sp3-20261113/evidence.zip) · 56,975,068 bytes

SHA256: `ae7b3ac863c02ddab9e1c6f52155465df7ebf366680f16e708fd7b0e798be9e8`

## NuCLS 정규화·51시야 평가 보충 (선행 ZIP 필요)

[ZIP 다운로드](https://raw.githubusercontent.com/sokldjs554/pathology-edge/dced5d0cfaee955015f0ece599bb29ce808ccc1f/artifacts/experiments/nucls-alignment-20261113/evidence-v2.zip) · 37,542,882 bytes

SHA256: `5cbcb9b667484870c2e6ce64ae109576f2b57d35afbb58339bbd6c90633cf5b0`

## 사용자 C++·CNN/ViT 제출 원본

[ZIP 다운로드](https://raw.githubusercontent.com/sokldjs554/pathology-edge/dced5d0cfaee955015f0ece599bb29ce808ccc1f/artifacts/learning/step56-user-evidence/research-evidence.zip) · 20,070,666 bytes

SHA256: `136a3c0ebae3f32ee7970160700922179485b27fa40b6f07df791d4d965d3895`

## 사용자 보정 head 제출 원본

[ZIP 다운로드](https://raw.githubusercontent.com/sokldjs554/pathology-edge/dced5d0cfaee955015f0ece599bb29ce808ccc1f/artifacts/experiments/user-vit-refinement-20261112/evidence.zip) · 20,031,212 bytes

SHA256: `a9d7a597e21528cbb81e07e881ed9f55fd13e6ef5fdcb299991c265ee65d17d1`

## 개발 환경 보정3개 seed

[ZIP 다운로드](https://raw.githubusercontent.com/sokldjs554/pathology-edge/dced5d0cfaee955015f0ece599bb29ce808ccc1f/artifacts/experiments/refinement-repeats-20261111/evidence.zip) · 59,384,311 bytes

SHA256: `50e31c733d30f17a1d8f80256e19fb2ebd724361054f4086114fd3846ffc2ad4`

## MoNuSeg 고정 모델 외부 평가

[ZIP 다운로드](https://raw.githubusercontent.com/sokldjs554/pathology-edge/dced5d0cfaee955015f0ece599bb29ce808ccc1f/artifacts/experiments/external-monuseg-20261111/evidence.zip) · 102,467,930 bytes

SHA256: `89d46ac818f38c4e680a73eedf660ced544f2e71a4856af4db4f21335b2c26a5`

## 원본 WSI·주석 직접 연결 평가

[ZIP 다운로드](https://raw.githubusercontent.com/sokldjs554/pathology-edge/dced5d0cfaee955015f0ece599bb29ce808ccc1f/artifacts/experiments/original-wsi-pairs-20261112/evidence.zip) · 63,937,336 bytes

SHA256: `2f6f2eed8bd53620991e42b935cc0a632cf4c14a893fbc81b4784b8da8d54484`

BCData는 공개된 집계·입력 해시·재현 코드만 이 ZIP에 포함하며 원자료를 재배포하지 않습니다.

## U87–U97 후속 실험의 전체 재현 원본

이 통합 ZIP에는 집계·선택·감사·검토 화면을 발췌했습니다. 모델과 모든 압축 예측/피크, 모바일 캡처, 당시 README를 포함한 실행용 원본은 아래에 그대로 보존했습니다. 통합 ZIP을 완전한 추론 설치 묶음으로 사용하지 마세요.

- [PathologyEdge-Final-Handoff-20261113.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/7a13d43993b179a359fbe8314392e0ae34276325/artifacts/handoff/PathologyEdge-Final-Handoff-20261113.zip) — 16,397,030 bytes, SHA256 `a74b32bcfacf0f347600b2f6efd627d1b808cca338d0c975227a801def50b073`
- [PathologyEdge-AutoKi67-Addendum-20261113.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/7a13d43993b179a359fbe8314392e0ae34276325/artifacts/handoff/PathologyEdge-AutoKi67-Addendum-20261113.zip) — 2,803,064 bytes, SHA256 `0d38286f5f6df530e5dd38fcebdb9f0125f17daf214257cc31ac21676e732325`
- [PathologyEdge-CandidateFilter-20261113.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/7a13d43993b179a359fbe8314392e0ae34276325/artifacts/handoff/PathologyEdge-CandidateFilter-20261113.zip) — 2,195,779 bytes, SHA256 `4e4349863459bc0c4cbe61145fbcf2fd513cfb4fc1200b5327d47594ce68262a`
- [PathologyEdge-LearnedCenters-20261113.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/7a13d43993b179a359fbe8314392e0ae34276325/artifacts/handoff/PathologyEdge-LearnedCenters-20261113.zip) — 5,474,802 bytes, SHA256 `a954552abde0d90ec761247b74971b0d5499119b723ac4948ce93a64f0e3b145`
- [PathologyEdge-RecallReview-20261113.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/7a13d43993b179a359fbe8314392e0ae34276325/artifacts/handoff/PathologyEdge-RecallReview-20261113.zip) — 5,593,732 bytes, SHA256 `08a3bd1197bce79dacb20f8d67e790de55400442ef9fe6d20d11d82aec47af00`
