# 화면과 실제 오류 사례

기존 개발 단계의 보관 캡처와 실제 저장 예측의 그림입니다. 새 촬영·사용자 신규 검토로 기록하지 않습니다. 라이선스는 `LICENSES_AND_SCOPE.txt`를 따릅니다.

### NuCLS 정렬 비교 · 사용자 U86은 세 패널 표시 확인

![NuCLS 정렬 비교 · 사용자 U86은 세 패널 표시 확인](artifacts/experiments/nucls-alignment-20261113/figures/alignment-example.png)

### NuCLS 이전15시야 최대 하락 · 사용자 U84 표시 확인

![NuCLS 이전15시야 최대 하락 · 사용자 U84 표시 확인](artifacts/experiments/nucls-sp3-20261113/largest-decrease.png)

### NuCLS 전체51시야 중 최대 하락 · 실제 저장 결과

![NuCLS 전체51시야 중 최대 하락 · 실제 저장 결과](artifacts/experiments/nucls-alignment-20261113/figures/largest-decrease51.png)

### NuCLS 정규화36쌍 모음 1/3 · 개발 환경 검토

![NuCLS 정규화36쌍 모음 1/3 · 개발 환경 검토](artifacts/experiments/nucls-alignment-20261113/figures/normalized36-sheet-1.png)

### NuCLS 정규화36쌍 모음 2/3 · 개발 환경 검토

![NuCLS 정규화36쌍 모음 2/3 · 개발 환경 검토](artifacts/experiments/nucls-alignment-20261113/figures/normalized36-sheet-2.png)

### NuCLS 정규화36쌍 모음 3/3 · 개발 환경 검토

![NuCLS 정규화36쌍 모음 3/3 · 개발 환경 검토](artifacts/experiments/nucls-alignment-20261113/figures/normalized36-sheet-3.png)

### 초기 데스크톱 화면 · 당시 보관 캡처

![초기 데스크톱 화면 · 당시 보관 캡처](artifacts/ui/before-desktop.png)

### 목적·사용 흐름을 보강한 작업대 · 당시 보관 캡처

![목적·사용 흐름을 보강한 작업대 · 당시 보관 캡처](artifacts/ui/interview/after-first.png)

### TNBC10_1 악화 경계 · 당시 보관 캡처

![TNBC10_1 악화 경계 · 당시 보관 캡처](artifacts/ui/interview/after-10_1-worsened.png)

### 작은 화면 · 당시 보관 캡처

![작은 화면 · 당시 보관 캡처](artifacts/ui/interview/after-375.png)

### 실제 WSI 전체 탐색 · 당시 보관 캡처

![실제 WSI 전체 탐색 · 당시 보관 캡처](artifacts/ui/wsi/wsi-overview.png)

### WSI 제한된 ROI 경계 비교 · 당시 보관 캡처

![WSI 제한된 ROI 경계 비교 · 당시 보관 캡처](artifacts/ui/wsi/wsi-boundary.png)

### WSI 후보·원 패치 출처 · 당시 보관 캡처

![WSI 후보·원 패치 출처 · 당시 보관 캡처](artifacts/ui/wsi/wsi-candidate-provenance.png)

### IHC 제공 중심의 정답·예측 분류 · 당시 보관 캡처

![IHC 제공 중심의 정답·예측 분류 · 당시 보관 캡처](artifacts/ui/wsi/ihc-desktop.png)

### 사용자 CNN/ViT 실행09_1 · 실제 저장 출력의 악화 ROI

![사용자 CNN/ViT 실행09_1 · 실제 저장 출력의 악화 ROI](artifacts/experiments/user-cnn-vit-errors-20261112/worsened-crop.png)

### 사용자 CNN/ViT 실행09_6 · 실제 저장 출력의 개선 ROI

![사용자 CNN/ViT 실행09_6 · 실제 저장 출력의 개선 ROI](artifacts/experiments/user-cnn-vit-errors-20261112/improved-crop.png)

### 외부 MoNuSeg · 최대 하락 실제 사례

![외부 MoNuSeg · 최대 하락 실제 사례](artifacts/experiments/external-monuseg-20261111/largest-decrease.png)

### 외부 MoNuSeg · 최대 상승 실제 사례

![외부 MoNuSeg · 최대 상승 실제 사례](artifacts/experiments/external-monuseg-20261111/largest-increase.png)

### 원본 GDC 연결 A0ST · 유효 주석 영역·실제 오류

![원본 GDC 연결 A0ST · 유효 주석 영역·실제 오류](artifacts/experiments/original-wsi-pairs-20261112/TCGA-A2-A0ST-linked-errors.png)

### 원본 GDC 연결 A0SX · 유효 주석 영역·실제 오류

![원본 GDC 연결 A0SX · 유효 주석 영역·실제 오류](artifacts/experiments/original-wsi-pairs-20261112/TCGA-A2-A0SX-linked-errors.png)

### 원본 미러 연결 A0D2 · 윤곽 정답 없이 배경 대조

![원본 미러 연결 A0D2 · 윤곽 정답 없이 배경 대조](artifacts/experiments/original-wsi-pairs-20261112/TCGA-A2-A0D2-linked-errors.png)