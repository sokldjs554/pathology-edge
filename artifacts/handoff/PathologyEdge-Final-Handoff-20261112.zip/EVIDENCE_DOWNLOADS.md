# 큰 원본 증거 ZIP

전달 ZIP의 용량을 줄이기 위해 아래 원본 묶음은 포함하지 않고 고정 커밋의 직접 다운로드를 연결했습니다. 사용자 제출 원본과 개발 환경 실행을 구분합니다. 각 원본 ZIP의 CRC와 SHA를 포장 시 확인했습니다. 원자료·모델 라이선스 조건을 유지하세요.

## 사용자 C++·CNN/ViT 제출 원본

[ZIP 다운로드](https://raw.githubusercontent.com/sokldjs554/pathology-edge/e2833ded53bedb71611e72f148a093b78b298412/artifacts/learning/step56-user-evidence/research-evidence.zip) · 20,070,666 bytes

SHA256: `136a3c0ebae3f32ee7970160700922179485b27fa40b6f07df791d4d965d3895`

## 사용자 보정 head 제출 원본

[ZIP 다운로드](https://raw.githubusercontent.com/sokldjs554/pathology-edge/e2833ded53bedb71611e72f148a093b78b298412/artifacts/experiments/user-vit-refinement-20261112/evidence.zip) · 20,031,212 bytes

SHA256: `a9d7a597e21528cbb81e07e881ed9f55fd13e6ef5fdcb299991c265ee65d17d1`

## 개발 환경 보정3개 seed

[ZIP 다운로드](https://raw.githubusercontent.com/sokldjs554/pathology-edge/e2833ded53bedb71611e72f148a093b78b298412/artifacts/experiments/refinement-repeats-20261111/evidence.zip) · 59,384,311 bytes

SHA256: `50e31c733d30f17a1d8f80256e19fb2ebd724361054f4086114fd3846ffc2ad4`

## MoNuSeg 고정 모델 외부 평가

[ZIP 다운로드](https://raw.githubusercontent.com/sokldjs554/pathology-edge/e2833ded53bedb71611e72f148a093b78b298412/artifacts/experiments/external-monuseg-20261111/evidence.zip) · 102,467,930 bytes

SHA256: `89d46ac818f38c4e680a73eedf660ced544f2e71a4856af4db4f21335b2c26a5`

## 원본 WSI·주석 직접 연결 평가

[ZIP 다운로드](https://raw.githubusercontent.com/sokldjs554/pathology-edge/e2833ded53bedb71611e72f148a093b78b298412/artifacts/experiments/original-wsi-pairs-20261112/evidence.zip) · 63,937,336 bytes

SHA256: `2f6f2eed8bd53620991e42b935cc0a632cf4c14a893fbc81b4784b8da8d54484`

BCData는 공개된 집계·입력 해시·재현 코드만 이 ZIP에 포함하며 원자료를 재배포하지 않습니다.
