# 면접관을 위한 경계 검토

2026-11-08 (Asia/Seoul). [공개 데모](https://pathology-edge-lab.ykh13571.chatgpt.site/) · [저장소](https://github.com/sokldjs554/pathology-edge).

## 수정 전 확인

- 시작 브랜치 `main`, 커밋 `d1d0b757c11768f5ee7265aad0c07b58f6e3b2e7`, 미반영 변경 없음.
- 공개 버전4의 UI 소스는 GitHub `2eb23c9`, Sites 소스 `e6bfb748f1ecb2eb9f9c1b6cecdfa368682ff4b2`. 이후 main 변경은 문서뿐이었습니다.
- 배포의 47개 정적 파일을 저장소와 바이트 대조했습니다. [기록](https://github.com/sokldjs554/pathology-edge/blob/a21bb05c4e22e4fd78718cd230312a59109243c7/artifacts/ui/interview/before-files.json).
- 수정 직전 [실제 배포 브라우저 검사](https://github.com/sokldjs554/pathology-edge/actions/runs/42400413971): Chromium·WebKit 각각 19개 통과. 예제 전환, 원본 픽셀, 동기화 확대·이동, NMS, 반응형 및 실패 상태 확인.
- 문제: 목적과 읽는 순서가 안내 창 안에 있었고, ‘경계로 이동’은 항상 (256,256)으로 이동했습니다. 실제 오차가 있는 위치를 고르지 않았습니다. 실험 표에는 내부 Dice와 시간 비용의 연결, 이미지별 증가·감소가 빠져 있었습니다. raw 후보 번호는 패널에만 있었습니다.

## 화면 변경과 참고한 UI

기존 [UI 조사](UI_REVIEW.md)의 QuPath(영상+측정 패널), Aperio(개요도·시야 이동), 에이비스 공개 자료(영상과 세포 수준 결과 연결)를 그대로 기반으로 했습니다. 이번 변경은 제품 화면 복제가 아닌, 이 프로젝트의 경계 비교를 설명하는 작은 안내와 근거 탐색 기능입니다. 제품 설치·임상 워크플로 검증을 수행한 것은 아닙니다.

- 작업대 위 두 줄: 목적과 **예제 선택 → 경계 비교 → 결과 확인**. 큰 소개 카드나 별도 랜딩 페이지를 만들지 않았습니다.
- ‘좋아진 경계 보기’ / ‘나빠진 경계 보기’: 실제 예제와 좌표를 함께 전환. ‘현재 예제 경계’: 현재 이미지에서 절대 순변화가 가장 큰 사례.
- A(무겹침)와 B(64px 겹침)의 같은 PNG 좌표에 흰 64×64 상자를 표시합니다. 청록은 정답 일치로 바뀐 픽셀, 분홍은 불일치로 바뀐 픽셀입니다. ‘달라진 픽셀 강조’를 끄면 실제 분할 표시를 직접 비교할 수 있습니다.
- 결과 패널의 **선택 경계**는 상자와 경계 띠가 겹치는 영역의 국소 Dice입니다. 아래 **평가 영역** 표는 이미지 전체/모든 경계/내부의 기존 저장 지표이며 확대해도 바뀌지 않습니다.
- 실험: 7장 평균, 내부 점수, 시간 중앙값·5.41배 비용, 7개 개별 결과, 원본 정밀도 차이를 함께 표시합니다. `10_1` 악화도 숨기지 않습니다.
- 실제 NMS 쌍은 원시 후보 번호와 억제/유지 상자·연결선으로 추적합니다. 병합 후에는 유지 raw 번호가 남습니다. 이것은 저장 NMS 대응이며 같은 실제 핵이라는 독립 정답이 아닙니다.
- 용어 안내는 클릭/키보드로 열 수 있습니다. Dice·IoU·stride·후보·병합·Δ·평가 범위를 설명합니다.
- 실제 원본/모델/결과는 보존합니다. 실시간 분석, Ki-67 정량화, WSI 전체 처리, 외부·임상 검증은 제공하지 않습니다.

## 사례 선택 기준과 근거

[구현](https://github.com/sokldjs554/pathology-edge/blob/a21bb05c4e22e4fd78718cd230312a59109243c7/src/pathology_edge/review_cases.py) · [생성 데이터](https://github.com/sokldjs554/pathology-edge/blob/a21bb05c4e22e4fd78718cd230312a59109243c7/dist/cases.json) · [검증](https://github.com/sokldjs554/pathology-edge/blob/a21bb05c4e22e4fd78718cd230312a59109243c7/tests/test_review_cases.py).

1. 저장된 PNG 예측 오버레이의 alpha>0을 이진 예측, GT의 gray>127을 이진 정답으로 읽습니다. 모델 재학습·추론이나 새 라벨 생성은 없습니다.
2. 기준 내부 경계 x/y=128,256,384의 양쪽 8px 띠를 사용합니다. ROI는 64×64px, 중심의 한 축은 경계 위에 있고 다른 축은 64..448에서 16px 간격입니다. 외곽 32px를 제외해 PNG 가장자리 영향을 줄입니다. 좌표는 반열린 `[x0,x1)×[y0,y1)`입니다.
3. ROI∩경계 띠 안에서 정답 핵 ≥32px, 달라진 예측 ≥16px, 순변화 절댓값 ≥16px를 요구합니다. ‘개선’은 오류→정답 픽셀 − 정답→오류 픽셀이 양수이며 국소 Dice도 증가해야 합니다. ‘악화’는 둘 다 반대입니다.
4. 이미지·방향별로 순변화가 가장 큰 한 영역을 선택합니다. 동률은 달라진 픽셀 수 내림차순, y→x 오름차순. 해당 방향이 없으면 만들지 않습니다. 7장에 총 11개 사례입니다.
5. 상단 대표 버튼은 이미지 전체와 모든 경계 Dice도 같은 방향인 사례 중 순변화가 가장 큰 것을 고릅니다. 이미지 간 동률은 ID, y, x 순입니다. 현재 예제 버튼은 해당 이미지 사례 중 순변화 절댓값이 큰 쪽입니다.
6. 생성 JSON은 예측·GT·results 원본 해시와 손실 없는 픽셀 run `[local_y, local_x, length]`를 포함합니다. 브라우저는 results 해시를 확인하고, 열 때마다 강조 픽셀과 국소 Dice를 실제 로딩한 마스크로 재검사합니다. 맞지 않으면 강조를 중단하며 기존 결과를 조작하지 않습니다.

| 사례 | 중심 x,y | 오류→정답 px | 정답→오류 px | 국소 경계 Dice A→B | 설명 |
|---|---:|---:|---:|---:|---|
| 대표 개선 `11_1` | 128,272 | 268 | 11 | 0.6262→0.8539 | 이미지 전체·모든 경계도 증가 |
| 대표 악화 `10_3` | 256,240 | 1 | 155 | 0.6324→0.5279 | 이미지 전체·모든 경계도 감소 |
| 첫 예제 악화 `10_1` | 112,128 | 10 | 162 | 0.5458→0.4333 | 현재 예제 경계 버튼 |
| `10_1`의 국소 개선 | 384,336 | 52 | 15 | 0.6348→0.7266 | 국소 개선과 이미지 전체 악화가 동시에 가능 |

이 위치는 **테스트 정답을 보고 고른 사후 설명 사례**입니다. 대표 성능 추정·독립 검증·유의성·경계 처리만의 인과 효과를 주장하지 않습니다. 모델/threshold는 그대로 유지했으며 사례 선택으로 다시 튜닝하지 않았습니다. 강조 영역은 세포 instance가 아니라 이진 핵/배경 픽셀입니다. 좋은 픽셀도 배경 오검출 해소일 수 있습니다.

## 저장 수치와의 대조

[픽셀·수치·보존 감사](https://github.com/sokldjs554/pathology-edge/blob/a21bb05c4e22e4fd78718cd230312a59109243c7/artifacts/ui/interview/result-audit.json): 7장×2방식×3범위의 Dice **42개**를 원본 PNG로 다시 계산해 저장 값과 대조했습니다. 6개 평균과 2개 시간 중앙값도 일치합니다. 모델, results.json, 42개 PNG, 사용자 함수 총45개 파일은 수정 전과 바이트가 같습니다.

| 범위 | A 원본 | B 원본 | B−A 원본 | UI 표시 A→B |
|---|---:|---:|---:|---|
| 전체 Dice | 0.558001243639622 | 0.5607900860028092 | +0.0027888423631872 | 0.558→0.561 |
| 경계 Dice | 0.4917929383428104 | 0.5272611646418014 | +0.035468226298991 | 0.492→0.527 |
| 내부 Dice | 0.5728662878255809 | 0.5696297743598978 | −0.0032365134656831 | 0.573→0.570 |
| 시간 중앙값 | 57.17446799997106 ms | 309.3040609999207 ms | 약5.4098배 | 57.2→309.3 ms |

표시된 0.527−0.492는 0.035이지만 실제 원본 차이는 0.035468…입니다. Δ는 원본으로 계산한 뒤 반올림합니다. Dice 평균은 이미지별 산술평균이며, 픽셀을 합친 점수가 아닙니다. 시간은 예열 후 이미지별 CPU 3회 중앙값을 7장 사이에서 다시 중앙값으로 집계했습니다. AMD EPYC 9V74, Torch 4 threads, 모델 로딩·디스크 I/O·지표 계산 제외입니다. 웹 화면 로딩 시간을 뜻하지 않습니다.

`10_1` 전체 Dice 0.650462→0.636666, 경계 0.682676→0.649451, 시간 67.0303→309.3041ms입니다. 전체 Dice 증가3장·감소4장이고, 테스트는 그룹10/11의 7장뿐입니다. 그룹10은 네 장 모두 감소, 그룹11은 세 장 모두 증가합니다. 폴더 그룹을 실제 환자 ID와 독립 대조하지 않았습니다. 단일 seed·소수 그룹이므로 일반적·임상적 개선을 주장할 수 없습니다.

## 사용자가 직접 확인할 첫 단계 — 아직 미확인

1. 데모를 열고 **현재 예제 경계**를 누릅니다. `10_1`의 동일 좌표 상자가 양쪽에 나타나며 국소 Dice 0.546→0.433, 10px 개선·162px 악화가 표시되어야 합니다.
2. **좋아진 경계 보기**를 누릅니다. `11_1`, 중심(128,272), 268px 개선·11px 악화로 바뀌는지 확인합니다. ‘달라진 픽셀 강조’를 끄고 켜며 원래 분할도 비교합니다.
3. **나빠진 경계 보기**로 `10_3`을 엽니다. 두 영상에서 드래그 또는 두 손가락 스크롤로 같은 시야가 이동하는지 확인합니다. Ctrl/⌘+스크롤은 확대입니다.
4. **③ 결과 확인**에서 평균 0.558→0.561, 경계 0.492→0.527, 시간 5.41배와 3장 증가/4장 감소를 확인합니다.
5. 시간이 되면 `11_2` → 중복 병합 → 결과 패널의 선택 후보 → 첫 병합 사례로 이동을 누릅니다. 분홍 억제 번호와 파란 유지 번호가 실제 목록과 일치해야 합니다. 작은 화면은 A/B 버튼으로 같은 좌표를 전환합니다.

우선 1–3의 결과만 보내 주세요. 브라우저/버전, 화면 크기, 예제 ID, 누른 버튼 순서, 실제로 보인 좌표·수치, 오류 시 화면 캡처 또는 콘솔 메시지가 있으면 원인을 확인하기 쉽습니다. 사용자가 직접 확인했다는 기록은 답변을 받은 뒤에만 추가합니다.

## 재현 명령

아래는 저장소 루트에서 실행합니다. 사용자 실행 완료를 뜻하지 않습니다.

```bash
# 기존 모델 추론 없이 사례 JSON을 재생성 (정해진 원본만 사용)
python -m pathology_edge.review_cases --dist dist
# 사례의 실제 픽셀·점수·선택 방향 검사
python -m pytest tests/test_review_cases.py -q
# 전체 제공 코드 검사; 사용자 과제 12개는 skip 유지
python -m pytest -q
# 화면 좌표 및 정적 연결 검사
node --test web-tests/viewer-math.test.cjs
python scripts/validate_demo.py
```

브라우저 검사는 저장소의 GitHub Actions `UI browser review`에서 target=checkout 또는 production으로 실행합니다. 이 환경에서는 직접 연결된 로컬 브라우저 도구가 없어 CI의 실제 Chromium/WebKit을 사용합니다. macOS 11.7.11의 실제 Safari·트랙패드 하드웨어 검증은 사용자의 확인 전입니다.

## 검증과 배포 근거

- 모델·데이터를 재실험하지 않고 기존 출력만 사용했습니다. 새 Python 검사는 손으로 만든 작은 마스크의 정답 변화, 무변화 경우, 실제 11개 사례의 run 복원·Dice·선택 방향·재생성 일치를 확인합니다.
- 저장소 루트 `python -m pytest -q`: **36 passed, 12 skipped**. 사용자 실습은 완료로 계산하지 않았습니다. Ubuntu Actions에서도 [동일 결과](https://github.com/sokldjs554/pathology-edge/actions/runs/42401568523)를 확인했습니다.
- [수정본 브라우저 검사](https://github.com/sokldjs554/pathology-edge/actions/runs/42401568608): Chromium·WebKit 각각 **26 passed**, 좌표 수학 **5 passed**. 기본 19개를 유지하고 경계 사례·강조 픽셀 색상/좌표·원본 정밀도·375/390/1024px·없는/불일치/손상된 사례 파일 검사를 추가했습니다.
- 첫 검사에서 Chromium의 기존 픽셀 검사 2개가 실패했습니다. 새 안내 문구의 소수점 줄 높이가 캔버스 위치를 0.1875px 밀고 마지막 행을 일부만 덮었습니다. 정수 줄 높이와 전체 backing-store 배경 채우기로 수정했습니다. 허용 오차로 기존 원본 픽셀 검사를 완화하지 않았습니다. [실패 원인 기록](https://github.com/sokldjs554/pathology-edge/blob/a21bb05c4e22e4fd78718cd230312a59109243c7/artifacts/ui/interview/first-check-summary.json).
- 공개 버전 **5**를 배포했습니다. GitHub UI 커밋 [`92780713cd6fd83d74fe39eca4e3fe33cf9fe0be`](https://github.com/sokldjs554/pathology-edge/commit/92780713cd6fd83d74fe39eca4e3fe33cf9fe0be), Sites 소스 `21855b4d96bb853ddd09966ceb9bc8a5e1a93fd2`. [배포 기록](https://github.com/sokldjs554/pathology-edge/blob/a21bb05c4e22e4fd78718cd230312a59109243c7/artifacts/ui/interview/deployment.json).
- CI가 실제 브라우저를 조작하고 Codex가 PNG 캡처를 열어 시각 검토했습니다. 사용자나 병리 전문가의 화면 검토를 완료로 기록하지 않았습니다.

| 요구 동작 | 확인 방법 |
|---|---|
| 목적·순서·첫 예제 | 첫 화면 문구/버튼 검사 + 실제 캡처 검토 |
| 예제와 이미지·수치 동시 변경 | 7장 순회, 원본 픽셀 및 JSON 지표 대조 |
| 같은 경계 위치 | 11개 사례 ID·PNG 중심 좌표, A/B 동기화 및 이동 검사 |
| 실제 강조 픽셀 | PNG/GT로 독립 run 복원, 브라우저 표시 RGB/위치 대조; 손상 run 거부 |
| 개선·악화 모두 | 대표 버튼, 전 사례 목록, `10_1` 회귀와 국소 개선 동시 공개 |
| 중복 후보 | 실제 suppressed/kept index, patch ID, bbox, raw 번호 시각 검토 |
| 평균·국소·시간 범위 | raw precision·scope·3/4장 변화 검사와 표 캡처 |
| 작은 화면 | 1024×768, 390×844, 375×667에서 ROI 전체 표시·A/B·패널 사용·넘침 검사 |
| 상태·기존 조작 | 로딩/HTTP 오류/이미지 누락/빈 데이터/재시도/빠른 변경, 드래그·스크롤·오버레이·1:1·개요도 |

최종 공개 주소 [검사 run 42401871346](https://github.com/sokldjs554/pathology-edge/actions/runs/42401871346)에서도 **Chromium 26/26, WebKit 26/26**, 재시도 없이 통과했습니다. 배포의 **49개 파일**을 커밋과 바이트 대조했습니다. [전체 파일 해시](https://github.com/sokldjs554/pathology-edge/blob/a21bb05c4e22e4fd78718cd230312a59109243c7/artifacts/ui/interview/production-files.json) · [최종 검증 기록](https://github.com/sokldjs554/pathology-edge/blob/a21bb05c4e22e4fd78718cd230312a59109243c7/artifacts/ui/interview/verification.json). 브라우저 경로에서 호스팅사가 HTML에 붙이는 스크립트는 기존 고정 템플릿 해시를 검사한 뒤에만 제외하며, UI 소스와 나머지 파일은 그대로 비교합니다. 별도 HTTP 경로의 49개 파일은 원본 바이트 그대로 일치했습니다.

문서·증거를 추가한 main 커밋은 위 UI 커밋과 다를 수 있지만 `dist/` 내용은 동일합니다. 현재 브랜치의 최신 UI는 버전5의 동일 소스입니다.

## 변경 전후 실제 브라우저 캡처

아래 PNG는 합성 UI가 아닌 실제 Chromium 캡처입니다. 변경 전은 수정 직전 버전4의 공개 주소, 변경 후는 버전5 공개 주소에서 촬영했습니다.

| 화면 | 변경 전 | 변경 후 |
|---|---|---|
| 첫 화면 | [작업대 v4](https://raw.githubusercontent.com/sokldjs554/pathology-edge/a21bb05c4e22e4fd78718cd230312a59109243c7/artifacts/ui/interview/before-desktop.png) | [목적·순서·사례 버튼](../artifacts/ui/interview/after-first.png) |
| 실제 경계 변화 | 고정 중앙으로 이동 | [개선 11_1](https://raw.githubusercontent.com/sokldjs554/pathology-edge/a21bb05c4e22e4fd78718cd230312a59109243c7/artifacts/ui/interview/after-improved.png) · [악화 10_3](https://raw.githubusercontent.com/sokldjs554/pathology-edge/a21bb05c4e22e4fd78718cd230312a59109243c7/artifacts/ui/interview/after-worsened.png) · [10_1 악화](../artifacts/ui/interview/after-10_1-worsened.png) |
| 결과 해석 | 평균 Dice 중심 | [전체·경계·내부·시간·7개 개별 결과](https://raw.githubusercontent.com/sokldjs554/pathology-edge/a21bb05c4e22e4fd78718cd230312a59109243c7/artifacts/ui/interview/after-experiment.png) |
| 중복 후보 | 패널 번호 | [영상의 raw 억제/유지 번호](https://raw.githubusercontent.com/sokldjs554/pathology-edge/a21bb05c4e22e4fd78718cd230312a59109243c7/artifacts/ui/interview/after-merge.png) |
| 작은 화면 | [390px v4](https://raw.githubusercontent.com/sokldjs554/pathology-edge/a21bb05c4e22e4fd78718cd230312a59109243c7/artifacts/ui/interview/before-390.png) | [390px](https://raw.githubusercontent.com/sokldjs554/pathology-edge/a21bb05c4e22e4fd78718cd230312a59109243c7/artifacts/ui/interview/after-390.png) · [375px](../artifacts/ui/interview/after-375.png) |
| 파일 실패 | — | [사례 파일 404 주입 상태](https://raw.githubusercontent.com/sokldjs554/pathology-edge/a21bb05c4e22e4fd78718cd230312a59109243c7/artifacts/ui/interview/case-unavailable-injected.png) |

별도 WebKit 캡처: [개선 경계](https://raw.githubusercontent.com/sokldjs554/pathology-edge/a21bb05c4e22e4fd78718cd230312a59109243c7/artifacts/ui/interview/webkit-improved.png), [375px](https://raw.githubusercontent.com/sokldjs554/pathology-edge/a21bb05c4e22e4fd78718cd230312a59109243c7/artifacts/ui/interview/webkit-375.png). 결과·기능 검사와 시각 검토에서 미해결 오류는 발견하지 못했습니다. 물리적 Mac 트랙패드와 사용자의 브라우저 버전, 임상적 타당성은 이번 검증 범위 밖입니다.
