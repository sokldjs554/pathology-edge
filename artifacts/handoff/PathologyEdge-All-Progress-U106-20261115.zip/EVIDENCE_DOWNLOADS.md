# 원본 증거·이전 발행본 다운로드

주요 원본과 과거 보관본의 고정 커밋 URL·SHA256입니다. 사용자 원본 2개는 이번 ZIP에도 들어 있습니다. 이전 전달본은 당시 상태이며 현재 판단은 CURRENT_STATUS.md를 따릅니다. 그 외 대용량 단일 파일과 추가 화면은 FILE_INVENTORY.json에서 찾습니다.

- **별도 다운로드**: [artifacts/experiments/cnn-vit-repeats-20261111/pair-20261113.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/experiments/cnn-vit-repeats-20261111/pair-20261113.zip) — 19,699,961 bytes
  SHA256: `dd6c8b1f07863f9c324070b0a6729a3a5bf395eccf0b31eee58b87ffe95a594d`
- **별도 다운로드**: [artifacts/experiments/cnn-vit-repeats-20261111/pair-20261114.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/experiments/cnn-vit-repeats-20261111/pair-20261114.zip) — 19,476,314 bytes
  SHA256: `987362debd564d65b44163234b29bee25e64f1883fde7c95317e8e1e153b9e10`
- **별도 다운로드**: [artifacts/experiments/cnn-vit-repeats-20261111/pair-20261115.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/experiments/cnn-vit-repeats-20261111/pair-20261115.zip) — 19,263,917 bytes
  SHA256: `d64e70fc03241ff611c0291e81a9971e5380c7188d5956559267b0b00c4ccfb6`
- **별도 다운로드**: [artifacts/experiments/external-monuseg-20261111/evidence.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/experiments/external-monuseg-20261111/evidence.zip) — 102,467,930 bytes
  SHA256: `89d46ac818f38c4e680a73eedf660ced544f2e71a4856af4db4f21335b2c26a5`
- **별도 다운로드**: [artifacts/experiments/ki67-final-transfer-20261115/evidence-controls.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/experiments/ki67-final-transfer-20261115/evidence-controls.zip) — 42,524,355 bytes
  SHA256: `bbe562d2f86fe46c8fcd451090ec7599cec627420945aab5674fb99874b663e2`
- **별도 다운로드**: [artifacts/experiments/ki67-final-transfer-20261115/evidence-primary.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/experiments/ki67-final-transfer-20261115/evidence-primary.zip) — 66,975,913 bytes
  SHA256: `21e976f5abce29263df4cda6a9bc7a748a350b9d14ab510d0819d2464573af82`
- **별도 다운로드**: [artifacts/experiments/ki67-normalized-20261114/evidence.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/experiments/ki67-normalized-20261114/evidence.zip) — 57,374,413 bytes
  SHA256: `c7cafea187c8c39a0363f415c5b585ed73589f3dcb3c10918f330e30989e5b83`
- **별도 다운로드**: [artifacts/experiments/ki67-supervision-20261114/evidence.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/experiments/ki67-supervision-20261114/evidence.zip) — 2,063,627 bytes
  SHA256: `ed038cef90a0349e735023725ee2674262a8308472718ac2107b09eb33b599d3`
- **별도 다운로드**: [artifacts/experiments/nucls-alignment-20261113/evidence-v2.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/experiments/nucls-alignment-20261113/evidence-v2.zip) — 37,542,882 bytes
  SHA256: `5cbcb9b667484870c2e6ce64ae109576f2b57d35afbb58339bbd6c90633cf5b0`
- **별도 다운로드**: [artifacts/experiments/nucls-sp3-20261113/evidence.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/experiments/nucls-sp3-20261113/evidence.zip) — 56,975,068 bytes
  SHA256: `ae7b3ac863c02ddab9e1c6f52155465df7ebf366680f16e708fd7b0e798be9e8`
- **별도 다운로드**: [artifacts/experiments/original-wsi-pairs-20261112/evidence.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/experiments/original-wsi-pairs-20261112/evidence.zip) — 63,937,336 bytes
  SHA256: `2f6f2eed8bd53620991e42b935cc0a632cf4c14a893fbc81b4784b8da8d54484`
- **별도 다운로드**: [artifacts/experiments/panoptils-wsi-probe-20261112/evidence.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/experiments/panoptils-wsi-probe-20261112/evidence.zip) — 34,880,532 bytes
  SHA256: `6d583d9e49600c7ea5564342eb9c3c88e4da94e2692b2a5a3972cb1630d4d171`
- **별도 다운로드**: [artifacts/experiments/refinement-repeats-20261111/evidence.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/experiments/refinement-repeats-20261111/evidence.zip) — 59,384,311 bytes
  SHA256: `50e31c733d30f17a1d8f80256e19fb2ebd724361054f4086114fd3846ffc2ad4`
- **ZIP 안 포함**: [artifacts/experiments/user-vit-refinement-20261112/evidence.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/experiments/user-vit-refinement-20261112/evidence.zip) — 20,031,212 bytes
  SHA256: `a9d7a597e21528cbb81e07e881ed9f55fd13e6ef5fdcb299991c265ee65d17d1`
- **별도 다운로드**: [artifacts/experiments/vit-refinement-reference-20261112/evidence.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/experiments/vit-refinement-reference-20261112/evidence.zip) — 20,104,624 bytes
  SHA256: `39d539190e89d94f9c27af38ac4eed8e7de22cea8af3547176bf47f6d7300123`
- **별도 다운로드**: [artifacts/handoff/PathologyEdge-AutoKi67-Addendum-20261113.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/handoff/PathologyEdge-AutoKi67-Addendum-20261113.zip) — 2,803,064 bytes
  SHA256: `0d38286f5f6df530e5dd38fcebdb9f0125f17daf214257cc31ac21676e732325`
- **별도 다운로드**: [artifacts/handoff/PathologyEdge-CandidateFilter-20261113.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/handoff/PathologyEdge-CandidateFilter-20261113.zip) — 2,195,779 bytes
  SHA256: `4e4349863459bc0c4cbe61145fbcf2fd513cfb4fc1200b5327d47594ce68262a`
- **별도 다운로드**: [artifacts/handoff/PathologyEdge-CenterRefit-Review-20261114.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/handoff/PathologyEdge-CenterRefit-Review-20261114.zip) — 2,506,477 bytes
  SHA256: `ce3b326762cfb8db9834b4ef6ec6bc2a9323cf25308c5322fe20a3fd23402e90`
- **별도 다운로드**: [artifacts/handoff/PathologyEdge-Cowork-U97-20261113.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/handoff/PathologyEdge-Cowork-U97-20261113.zip) — 24,135,855 bytes
  SHA256: `fc4362f179c03c20e6dbf40f702f44e87b0b68d1a5f1d4cbf60651524acab9ee`
- **별도 다운로드**: [artifacts/handoff/PathologyEdge-Cowork-v2.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/handoff/PathologyEdge-Cowork-v2.zip) — 3,579,126 bytes
  SHA256: `f276a4752c988215721a4966b973e89453a083f7b13f18b6fe5a62a76b2b4a8d`
- **별도 다운로드**: [artifacts/handoff/PathologyEdge-Cowork.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/handoff/PathologyEdge-Cowork.zip) — 2,104,347 bytes
  SHA256: `03162180b9fb3d7b8696d698b9a20eb0f93f3de1fb58d42a52b648e33159af57`
- **별도 다운로드**: [artifacts/handoff/PathologyEdge-Final-Handoff-20261112-v2.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/handoff/PathologyEdge-Final-Handoff-20261112-v2.zip) — 11,552,627 bytes
  SHA256: `ed4c0479ed515d8d448a007f586b7b1b36a5569a70ad3ab4f4abc9fc11ab35f1`
- **별도 다운로드**: [artifacts/handoff/PathologyEdge-Final-Handoff-20261112.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/handoff/PathologyEdge-Final-Handoff-20261112.zip) — 11,528,072 bytes
  SHA256: `643cb7d5f52d675e4490430e71d8b41cb0bdd8fd8afed29175c5104f18efab73`
- **별도 다운로드**: [artifacts/handoff/PathologyEdge-Final-Handoff-20261113.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/handoff/PathologyEdge-Final-Handoff-20261113.zip) — 16,397,030 bytes
  SHA256: `a74b32bcfacf0f347600b2f6efd627d1b808cca338d0c975227a801def50b073`
- **별도 다운로드**: [artifacts/handoff/PathologyEdge-FinalTransfer-20261115.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/handoff/PathologyEdge-FinalTransfer-20261115.zip) — 4,610,073 bytes
  SHA256: `bf766beaf008baaca58e5292ab322263e7e9ace22a641aa99db0d10e60d81138`
- **별도 다운로드**: [artifacts/handoff/PathologyEdge-LearnedCenters-20261113.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/handoff/PathologyEdge-LearnedCenters-20261113.zip) — 5,474,802 bytes
  SHA256: `a954552abde0d90ec761247b74971b0d5499119b723ac4948ce93a64f0e3b145`
- **별도 다운로드**: [artifacts/handoff/PathologyEdge-Localization-Review-20261114.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/handoff/PathologyEdge-Localization-Review-20261114.zip) — 2,236,926 bytes
  SHA256: `f1557795835b509d8a0fdbf80890f347b2a40902fd9b61aa79381c667d3104f3`
- **별도 다운로드**: [artifacts/handoff/PathologyEdge-Normalized-Review-20261114.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/handoff/PathologyEdge-Normalized-Review-20261114.zip) — 1,714,110 bytes
  SHA256: `0f890889921ae10eeb87bf9d162c904ec20693bd51ad6d750a88489b1986ac89`
- **별도 다운로드**: [artifacts/handoff/PathologyEdge-RecallReview-20261113.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/handoff/PathologyEdge-RecallReview-20261113.zip) — 5,593,732 bytes
  SHA256: `08a3bd1197bce79dacb20f8d67e790de55400442ef9fe6d20d11d82aec47af00`
- **별도 다운로드**: [artifacts/handoff/PathologyEdge-UnionGate-Review-20261113.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/handoff/PathologyEdge-UnionGate-Review-20261113.zip) — 1,769,895 bytes
  SHA256: `16485c66fd57cb741414874583177214b0502a0274d3094ad27b17b3d30b6f05`
- **ZIP 안 포함**: [artifacts/learning/step56-user-evidence/research-evidence.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/learning/step56-user-evidence/research-evidence.zip) — 20,070,666 bytes
  SHA256: `136a3c0ebae3f32ee7970160700922179485b27fa40b6f07df791d4d965d3895`
- **ZIP 안 포함**: [artifacts/learning/step57-exercise.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/learning/step57-exercise.zip) — 3,234 bytes
  SHA256: `f9466bf39394f583426195901f698a7446d94d5acf567085ba68cf5600a7eff4`
- **별도 다운로드**: [artifacts/reproductions/docker-033720d/evidence.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/reproductions/docker-033720d/evidence.zip) — 146,367 bytes
  SHA256: `bf3cb13db19cddeecb54058da3fe82b7cd4413411c5e02f18ba104913eee1b72`
- **별도 다운로드**: [artifacts/reproductions/docker-1744544/evidence.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/reproductions/docker-1744544/evidence.zip) — 149,302 bytes
  SHA256: `8b1e4c9ea80a3c85b1a38fe5c4ddae3820713378967a77f38cf07929a975e4bb`
- **별도 다운로드**: [artifacts/reproductions/docker-20cc5ac/evidence.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/reproductions/docker-20cc5ac/evidence.zip) — 137,309 bytes
  SHA256: `ab7fee6563ebe2b15ede45e251c35a07c270a29b1448ffd688864b721ca7a163`
- **별도 다운로드**: [artifacts/reproductions/docker-f90220d/attempt-1.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/reproductions/docker-f90220d/attempt-1.zip) — 123,530 bytes
  SHA256: `1a6ef24352c763657b6f158e39bb23ff150e13aa2dc35b3b7479e4032b49a18c`
- **별도 다운로드**: [artifacts/reproductions/docker-f90220d/attempt-2.zip](https://raw.githubusercontent.com/sokldjs554/pathology-edge/fbc5f0d7e09f151c2790eca5e7463b41fdf279e7/artifacts/reproductions/docker-f90220d/attempt-2.zip) — 123,558 bytes
  SHA256: `61c63f802e6478192239a645ddbd072404d176ff7b11587cf6622eeb0c63d656`
