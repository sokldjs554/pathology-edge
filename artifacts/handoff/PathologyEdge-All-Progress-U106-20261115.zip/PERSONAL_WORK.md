# 본인이 직접 수행한 부분 — 확인된 범위

이 목록은 실제 제출 코드·실행 출력·화면 확인 답변에 근거합니다. **전체 기록은 [U00–U106](docs/CONTRIBUTIONS.md)** 이며, 번호 107개에는 예정·보류 항목도 있습니다. 107개 모두 완료했다는 뜻이 아닙니다. 이 포장 작업에서 새 사용자 완료 기록을 만들지 않았습니다.

## 직접 작성한 7개 항목

각 파일의 틀·guard·fixture·학습기·기존 연결 코드에는 제공된 코드가 포함됩니다. 파일 전체나 모델 전체를 단독 작성했다고 표현하지 않습니다. 테스트 수는 당시 본인의 실행 보고이며 이번 포장 시 재실행한 결과가 아닙니다.

| 코드·함수 | 직접 작성 범위 | 당시 실행 보고 |
|---|---|---|
| [src/pathology_edge/learner_coordinates.py](src/pathology_edge/learner_coordinates.py) · `local_to_level0` | 좌표 변환·입력 검사 | 12 passed |
| [tests/learner/test_merge_counterexample.py](tests/learner/test_merge_counterexample.py) · `test_distance_rule_can_suppress_distinct_nuclei` | 서로 다른 핵을 하나로 억제하는 반례 테스트 본문 | 1 passed |
| [src/pathology_edge/learner_metrics.py](src/pathology_edge/learner_metrics.py) · `dice_score` | 영역 선택·입력 검사·Dice 계산 | 20 passed |
| [src/pathology_edge/learner_split.py](src/pathology_edge/learner_split.py) · `find_group_leaks` | split 간 그룹 누수 검사 | 18 passed |
| [src/pathology_edge/learner_losses.py](src/pathology_edge/learner_losses.py) · `soft_dice_loss` | sigmoid·이미지별 soft Dice·batch 평균 본문 | 8 passed |
| [src/pathology_edge/learner_wsi.py](src/pathology_edge/learner_wsi.py) · `roi_points_to_level0` | 실제 읽기 크기와 모델 크기의 scale 연결 | 8 passed |
| [src/pathology_edge/learner_refinement.py](src/pathology_edge/learner_refinement.py) · `LocalResidualHead` | 두 convolution·ReLU·0 초기화·잔차 연결 | 13 passed |

## 직접 실행·제출한 주요 작업

- 저장 Dice 42/42개·평균 6/6개 대조. 그룹 11개/이미지 50장, split 33/10/7 검사와 저장 이미지 해시 문자열 중복 검사.
- Codespaces CPU 기준 학습, BCE-only/직접 soft Dice 비교, 추가 세 seed의 여섯 학습 실행 및 로컬 감사 성공 출력.
- Ubuntu 고정 소스 재현(191개 테스트·C++ 재빌드·Dice·정적 데모), 원본 로그 commit·push·PR #1 생성·병합. Docker는 원격 CI 화면 확인이며 본인 로컬 Docker 빌드가 아닙니다.
- C++ 패치 추출 8조건·72개 시간 측정, CNN/ViT 단일 seed 비교, 직접 보정 head의 13개 테스트·학습 비교와 원본 ZIP 제출.
- BCData 공식 test 1,206파일 수신 보고, 109·367 두 이미지의 고정 모델 추론·기존 결과 대조와 화면 확인. BCData 전체 평가를 본인 실행으로 확장하지 않습니다.

## 직접 검토·해석한 내용

동기 이동과 경계 전후 비교, 개선·악화 사례, 후보 억제 반례, 픽셀 수와 핵 개수 구분, 전체/경계/내부/국소 점수 구분, WSI 전체 탐색과 일부 ROI 분석 구분, 정답 중심 조건 분류와 자동 검출 구분, 양성률 분모와 세포 분류 오류, 외부 악화·FP/FN·seed 안정성의 한계를 검토했습니다.

U101 방향 선택과 U102 설계 승인은 실험 실행 기록이 아닙니다. U103–U106은 안내된 화면과 표시/수치 유지 확인 범위이며, 독립 검산·전체 seed/영상 전수 검토·병리 전문가 판독으로 확대하지 않습니다. 마지막 사전학습·DeepLIIF 실험은 개발 환경의 자동 실행입니다.

## 본인이 제출한 원본 파일도 포함

- [C++·CNN/ViT 연구 원본 ZIP](artifacts/learning/step56-user-evidence/research-evidence.zip)
- [보정 head 원본 ZIP](artifacts/experiments/user-vit-refinement-20261112/evidence.zip) — 업로드명 `refinement-evidence.nvOJR4.zip`과 SHA256가 같습니다.

모든 개인 응답·출력 원문과 받은 도움: `artifacts/learning/step*-review.json` 및 관련 summary. 원본을 실제 수신한 실험은 원본 감사와 해시를, 채팅 출력만 받은 단계는 실행 보고라는 증거 범위를 유지합니다. [직접 연구 감사](docs/USER_RESEARCH_AUDIT.md), [보정 원본 감사](docs/USER_REFINEMENT_AUDIT.md).
