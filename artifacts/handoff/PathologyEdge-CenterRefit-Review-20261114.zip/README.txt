PathologyEdge — 검출기 추가 학습 검토

압축 해제 후 index.html을 브라우저로 여세요. 파일 열기가 제한되면 압축을 푼 폴더에서 python -m http.server 8000 --bind 127.0.0.1 을 실행하고 http://127.0.0.1:8000/ 에 접속하세요. 관리형 Chromium의 file:// 검사는 정책상 차단되었고 로컬 HTTP 방식과 외부 자원 없는 동작을 확인했습니다.
A/B가 같은 원영상인지 확인하고 후보·정답 표시를 껐다 켜세요. 표시만 바뀌고 수치는 유지돼야 합니다.
새 optimizer로 기존 체크포인트를24epoch 추가 학습했습니다. 연속40epoch 재현이 아닙니다.
표는 검증227장/4케이스입니다. 조건 미충족이면 B는 진단용이며 채택 모델이 아닙니다.
epoch0 대조는 넓어진 임계값 범위의 효과를 구분하기 위한 것입니다.
사용자 새 화면 확인은 아직 미완료입니다. 전체 source/results: https://github.com/sokldjs554/pathology-edge/tree/feat/auto-ki67
보고서 docs/KI67_CENTER_REFIT.md. 데이터 권리 ATTRIBUTION.txt 확인.
