PathologyEdge 후보 통합 + 이진 CNN 검토

압축을 푼 다음 index.html을 브라우저로 여세요. 네 화면은 같은 원영상입니다.
첫 사례에서 후보·정답 표시를 껐다 켜 보세요. 모바일에서는 네 화면이 세로로 나옵니다.

결과: 3개 seed, 총1,512조합 중 선택 조건 충족0개. 진단용 모델이며 성능 개선 채택 결과가 아닙니다.
새 테스트·외부 추론0장. 임상/WSI전체 검증 아님. 사용자 새 화면 확인은 대기 상태입니다.
REPORT.md: 실험 결과·범위·미해결 경미항목(uint8 직접 입력)을 포함한 보고서.
evidence/: 전체 seed 선택 결과와 독립 감사, 검증 기록.
desktop.png/mobile.png: 실제 Chromium 화면 캡처.
SHA256SUMS.json: 이 ZIP 각 파일의 SHA256.

전체 원본 점수·진단용 모델·고정 소스:
https://github.com/sokldjs554/pathology-edge/tree/d3935577fd16c1ee7fdf4657d473ffdae44132ee/artifacts/experiments/ki67-union-20261113
