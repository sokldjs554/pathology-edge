"""Recompute train-only smoothing using explicit Gaussian kernels and independent NMS."""
from pathlib import Path
import sys,json
import numpy as np
import torch
from scipy.ndimage import convolve1d
sys.path.insert(0,str(Path('scripts').resolve()))
from audit_ki67_union import independent_decode,_summary,compare_metrics
from pathology_edge.ki67_experiment import load_sample,verify_data,sha,fresh_json
from pathology_edge.ki67_normalized_centers import NormalizedCenterDetector
from pathology_edge.ki67_normalized_experiment import checked
from pathology_edge.ki67_centers import peak_candidates
from pathology_edge.ki67_center_refit import tensor
root=Path('work/ki67-supervision-20261114');dest=root/'smoothing-spike';protocol=json.loads((dest/'protocol.json').read_text());stored=json.loads((dest/'result.json').read_text());p=checked('work/normalized-centers-20261114',selected=True)
rows=[];cases={}
for r in json.loads((Path(p['parent'])/'source-manifest.json').read_text()):
 if r['split']=='train' and cases.get(r['case_id'],0)<8:rows.append(r);cases[r['case_id']]=cases.get(r['case_id'],0)+1
assert len(rows)==120 and len(cases)==15 and protocol['images']==[r['image'] for r in rows]
assert protocol['sigmas']==[0,1,2,3,4] and protocol['matching_radius']==6 and protocol['mode']=='scipy Gaussian reflect truncate3, float64 heat'
assert protocol['source_sha256']==sha(root/'smoothing_spike.py') and protocol['checkpoint_sha256']==sha(protocol['checkpoint'])
assert stored['heldout_inference_images']==0 and stored['train_images']==120
verify_data(p['data_dir'],rows);torch.set_num_threads(1);m=NormalizedCenterDetector(16);m.load_state_dict(torch.load(protocol['checkpoint'],weights_only=True,map_location='cpu'),strict=True);m.eval();refs=[];peaks={s:[] for s in protocol['sigmas']}
with torch.inference_mode():
 for r in rows:
  rgb,gt,gc=load_sample(p['data_dir'],r);refs.append(dict(image=r['image'],case_id=r['case_id'],gt_points=gt.tolist(),gt_classes=gc.tolist()));heat=torch.sigmoid(m(tensor(rgb[None])))[0,0].numpy().astype(np.float64)
  for s in peaks:
   if s:
    offsets=np.arange(-3*s,3*s+1,dtype=np.float64);kernel=np.exp(-.5*(offsets/s)**2);kernel/=kernel.sum();smoothed=convolve1d(convolve1d(heat,kernel,axis=0,mode='reflect'),kernel,axis=1,mode='reflect')
   else:smoothed=heat
   peaks[s].append(peak_candidates(smoothed))
expected={(s,t,d) for s in range(5) for t in (.01,.02,.03,.05,.075,.1,.15,.2,.3,.5,.7,.9) for d in (4,6,8)}
assert len(stored['trials'])==180 and {(t['sigma'],t['config']['threshold'],t['config']['min_distance']) for t in stored['trials']}==expected
for t in stored['trials']:compare_metrics(_summary(refs,[independent_decode(pt,sc,t['config'])[0] for pt,sc in peaks[t['sigma']]]),t)
key=lambda t:(t['case_macro_f1'],t['case_macro_recall'],t['config']['threshold'],t['config']['min_distance'])
best={s:max([t for t in stored['trials'] if t['sigma']==s],key=key) for s in peaks}
assert {str(s):v for s,v in best.items()}==stored['best_by_sigma']
a=best[0];eligible=[s for s in range(1,5) if best[s]['case_macro_f1']-a['case_macro_f1']>=.03-1e-12 and best[s]['tumor_recalls'][0]>=a['tumor_recalls'][0]]
picked=max(eligible,key=lambda s:(best[s]['case_macro_f1'],best[s]['case_macro_recall'],-s)) if eligible else None
assert picked==stored['selected_sigma']
report=dict(all_checks_passed=True,checkpoint_image_replays=120,derived_maps=600,metric_checks=180,selected_sigma=picked,heldout_inference_images=0,
 kernel_method='Explicit normalized exp(-x^2/2sigma^2) convolve1d, reflect, two axes; independent NMS; common existing peak/matching primitive',
 input_hashes={str(f.resolve()):sha(f) for f in (dest/'protocol.json',dest/'result.json',root/'smoothing_spike.py',Path(protocol['checkpoint']))},audit_source_sha256=sha(__file__))
fresh_json(dest/'audit.json',report);print(json.dumps(report))
