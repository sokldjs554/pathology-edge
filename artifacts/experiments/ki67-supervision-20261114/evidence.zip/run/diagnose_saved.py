from pathlib import Path
import json,gzip,hashlib
from collections import Counter
import numpy as np
from scipy.spatial.distance import cdist
from pathology_edge.ki67_union import retain_candidates
from pathology_edge.ki67_evaluation import match_points
root=Path('work/normalized-centers-20261114');out=Path('work/ki67-supervision-20261114')
results=[]
for seed in (20261117,20261118,20261119):
 d=root/f'width16-seed{seed}';result=json.loads((d/'result.json').read_text());chosen=result['diagnostic'];epoch=chosen['epoch'];config=chosen['config'];z=np.load(d/'validation-peaks.npz');refs=json.loads(gzip.decompress((d/'validation.json.gz').read_bytes()));off=z[f'offsets_{epoch}'];pt=z[f'points_{epoch}'].astype(float);sc=z[f'scores_{epoch}'].astype(float)
 reasons=[Counter() for _ in range(4)];fp=Counter();case_counts={};tp_dist=[];fn_border=0
 for i,r in enumerate(refs):
  gt=np.array(r['gt_points'],dtype=float).reshape(-1,2);gc=np.array(r['gt_classes']);raw=pt[off[i]:off[i+1]];scores=sc[off[i]:off[i+1]];q=retain_candidates(raw,scores,**config)['points_xy'];pairs=match_points(q,gt,6);gi={b for a,b in pairs};pi={a for a,b in pairs}
  nearraw=cdist(gt,raw)<=6;nearpass=cdist(gt,raw[scores>=config['threshold']])<=6;nearret=cdist(gt,q)<=6
  for j,c in enumerate(gc):
   reason=('matched' if j in gi else 'no_saved_peak_ge_0.01' if not nearraw[j].any() else 'below_threshold' if not nearpass[j].any() else 'distance_suppressed' if not nearret[j].any() else 'assignment_competition');reasons[c][reason]+=1
   if j not in gi and (gt[j].min()<8 or gt[j].max()>=216):fn_border+=1
  for j in range(len(q)):
   if j in pi:continue
   near=float(cdist(q[j:j+1],gt).min()) if len(gt) else float('inf')
   band='within6_competition' if near<=6 else '6_to12' if near<=12 else '12_to24' if near<=24 else 'beyond24_or_no_gt';fp[band]+=1
  tp_dist.extend(float(np.linalg.norm(q[a]-gt[b])) for a,b in pairs)
  counts=case_counts.setdefault(r['case_id'],np.zeros(3,dtype=int));counts += [len(pairs),len(q)-len(pairs),len(gt)-len(pairs)]
 results.append(dict(seed=seed,epoch=epoch,config=config,by_true_class=[dict(c) for c in reasons],fp_distance_to_nearest_gt=dict(fp),case_counts={k:v.tolist() for k,v in case_counts.items()},fn_within8px_border=fn_border,tp_distance_quantiles=np.quantile(tp_dist,[.25,.5,.75,.95]).tolist()))
p=json.loads((root/'protocol.json').read_text());rows=json.loads((Path(p['parent'])/'source-manifest.json').read_text());stats={}
for split in ('train','validation'):
 subset=[r for r in rows if r['split']==split];counts=np.array([list(r['class_counts'].values()) for r in subset]);stats[split]=dict(images=len(subset),empty=int((counts.sum(1)==0).sum()),class_names=list(subset[0]['class_counts']),class_counts=counts.sum(0).tolist(),cells_per_image_quantiles=np.quantile(counts.sum(1),[0,.25,.5,.75,1]).tolist())
report=dict(scope='Posthoc diagnosis on existing validation peaks, no new model/inference or heldout access. No-saved-peak means no saved peak at score>=0.01, not necessarily no mathematical maximum.',source_commit='de8c6d22f9bfc026e7dea390c93bf5462129d5cf',selection_sha256=hashlib.sha256((root/'selection.json').read_bytes()).hexdigest(),dataset=stats,models=results)
(out/'saved-error-diagnosis.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
