"""Authorized train-only loss diagnostic; not heldout evidence or product code."""
from pathlib import Path
import sys,json,time,hashlib
import numpy as np
import torch
from torch.nn import functional as F
from pathology_edge.ki67_normalized_centers import NormalizedCenterDetector
from pathology_edge.ki67_centers import center_target,center_focal_loss,peak_candidates
from pathology_edge.ki67_center_refit import tensor
from pathology_edge.ki67_union import retain_candidates,summarize_locations
from pathology_edge.ki67_experiment import load_sample,verify_data
MODE=sys.argv[1];assert MODE in ('focal','soft_mse','soft_bce')
root=Path('work/ki67-supervision-20261114');dest=root/('spike-'+MODE);dest.mkdir(exist_ok=False)
p=json.loads(Path('work/normalized-centers-20261114/protocol.json').read_text());allrows=json.loads((Path(p['parent'])/'source-manifest.json').read_text());rows=[];counts={}
for r in allrows:
 if r['split']=='train' and counts.get(r['case_id'],0)<8:rows.append(r);counts[r['case_id']]=counts.get(r['case_id'],0)+1
verify_data(p['data_dir'],rows)
samples=[];rgb=[];targets=[]
for r in rows:
 im,gt,gc=load_sample(p['data_dir'],r);rgb.append(im);targets.append(center_target(gt,im.shape[:2]));samples.append(dict(image=r['image'],case_id=r['case_id'],gt_points=gt,gt_classes=gc))
rgb=np.stack(rgb);targets=np.stack(targets)
protocol=dict(mode=MODE,scope='120 train images, first8 per training case; no validation/test/external inference',images=[r['image'] for r in rows],cases=counts,seed=20261117,steps=300,batch8=True,learning_rate=.001,threads=1,augmentation='same paired rot90/flips RGB[.9,1.1]',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),loss='focal reference or per-image soft-positive/soft-negative normalized MSE or BCE',model='same initialized normalized width16',decision='Among soft objectives with train best-case-F1 >= reference+0.03 and positive tumor recall>=reference, pick greater train F1; descriptive fitting diagnostic, not generalization evidence')
(dest/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
torch.set_num_threads(1);torch.use_deterministic_algorithms(True);torch.manual_seed(20261117);rng=np.random.default_rng(20261117);m=NormalizedCenterDetector(16);opt=torch.optim.Adam(m.parameters(),lr=.001)
(dest/'initial-tensors.json').write_text(json.dumps({k:hashlib.sha256(v.detach().numpy().tobytes()).hexdigest() for k,v in m.state_dict().items()},indent=2)+'\n')
def loss_fn(logits,y):
 if MODE=='focal':return center_focal_loss(logits,y)
 axes=(1,2,3);pos=y.sum(axes).clamp_min(1);neg=(1-y).sum(axes).clamp_min(1)
 if MODE=='soft_mse':e=(torch.sigmoid(logits)-y).square();return ((e*y).sum(axes)/pos+(e*(1-y)).sum(axes)/neg).mean()
 return ((F.softplus(-logits)*y).sum(axes)/pos+(F.softplus(logits)*(1-y)).sum(axes)/neg).mean()
start=time.perf_counter();history=[];order=np.empty(0,dtype=int);cursor=0
for step in range(1,301):
 if cursor>=len(order):order=rng.permutation(len(rgb));cursor=0
 ids=order[cursor:cursor+8];cursor+=8;x=tensor(rgb[ids]);y=torch.from_numpy(targets[ids,None].copy())
 for i in range(len(ids)):
  k=int(rng.integers(4));x[i]=torch.rot90(x[i],k,(1,2));y[i]=torch.rot90(y[i],k,(1,2))
  for dim in (1,2):
   if rng.random()<.5:x[i]=x[i].flip(dim);y[i]=y[i].flip(dim)
 x=(x*torch.from_numpy(rng.uniform(.9,1.1,(len(ids),3,1,1)).astype(np.float32))).clamp(0,1)
 opt.zero_grad(set_to_none=True);loss=loss_fn(m(x),y);assert torch.isfinite(loss);loss.backward();opt.step()
 if step%100==0:
  entry=dict(mode=MODE,step=step,loss=float(loss.detach()),seconds=time.perf_counter()-start);history.append(entry);print(json.dumps(entry),flush=True)
m.eval();found=[]
with torch.inference_mode():
 for im in rgb:
  pt,sc=peak_candidates(torch.sigmoid(m(tensor(im[None])))[0,0].numpy());found.append((pt,sc))
trials=[]
for threshold in (.01,.02,.03,.05,.075,.1,.15,.2,.3,.5,.7,.9):
 for distance in (4,6,8):
  trial=dict(config=dict(threshold=threshold,min_distance=distance),**summarize_locations([{**r,'points':retain_candidates(pt,sc,threshold,distance)['points_xy']} for r,(pt,sc) in zip(samples,found)]));trials.append(trial)
best=max(trials,key=lambda t:(t['case_macro_f1'],t['case_macro_recall'],t['config']['threshold'],t['config']['min_distance']))
torch.save(m.state_dict(),dest/'model.pt');report=dict(mode=MODE,best=best,trials=trials,history=history,seconds=time.perf_counter()-start,training_images=len(rows),heldout_inference_images=0)
(dest/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(mode=MODE,best=best,seconds=report['seconds'])),flush=True)
