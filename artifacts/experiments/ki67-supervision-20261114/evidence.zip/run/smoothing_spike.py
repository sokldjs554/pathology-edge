"""Train-only native heatmap smoothing probe, no change to matching radius."""
from pathlib import Path
import json,time
import numpy as np
import torch
from scipy.ndimage import gaussian_filter
from pathology_edge.ki67_experiment import load_sample,verify_data,sha
from pathology_edge.ki67_normalized_centers import NormalizedCenterDetector
from pathology_edge.ki67_centers import peak_candidates
from pathology_edge.ki67_center_refit import tensor
from pathology_edge.ki67_union import retain_candidates,summarize_locations
root=Path('work/ki67-supervision-20261114');dest=root/'smoothing-spike';dest.mkdir(exist_ok=False)
p=json.loads(Path('work/normalized-centers-20261114/protocol.json').read_text());records=json.loads((Path(p['parent'])/'source-manifest.json').read_text());rows=[];cases={}
for r in records:
 if r['split']=='train' and cases.get(r['case_id'],0)<8:rows.append(r);cases[r['case_id']]=cases.get(r['case_id'],0)+1
ckpt=Path('work/normalized-centers-20261114/width16-seed20261117/diagnostic.pt')
protocol=dict(scope='Post-loss-rejection train-only decoder hypothesis; no heldout inference',seed=20261117,checkpoint=str(ckpt.resolve()),checkpoint_sha256=sha(ckpt),images=[r['image'] for r in rows],sigmas=[0,1,2,3,4],mode='scipy Gaussian reflect truncate3, float64 heat',matching_radius=6,decision='Require best nonzero-sigma train caseF1 >= unsmoothed+0.03 and positive tumor recall>=unsmoothed; if supported fix this sigma for all3 frozen GN models before validation comparison',source_sha256=sha(__file__))
(dest/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
verify_data(p['data_dir'],rows);torch.set_num_threads(1);model=NormalizedCenterDetector(16);model.load_state_dict(torch.load(ckpt,weights_only=True,map_location='cpu'),strict=True);model.eval();samples=[];found={s:[] for s in protocol['sigmas']};start=time.perf_counter()
with torch.inference_mode():
 for r in rows:
  rgb,gt,gc=load_sample(p['data_dir'],r);heat=torch.sigmoid(model(tensor(rgb[None])))[0,0].numpy().astype(np.float64);samples.append(dict(image=r['image'],case_id=r['case_id'],gt_points=gt,gt_classes=gc))
  for s in found:found[s].append(peak_candidates(gaussian_filter(heat,sigma=s,mode='reflect',truncate=3) if s else heat))
best={};trials=[]
for s,peaks in found.items():
 subset=[]
 for threshold in (.01,.02,.03,.05,.075,.1,.15,.2,.3,.5,.7,.9):
  for distance in (4,6,8):
   trial=dict(sigma=s,config=dict(threshold=threshold,min_distance=distance),**summarize_locations([{**r,'points':retain_candidates(pt,sc,threshold,distance)['points_xy']} for r,(pt,sc) in zip(samples,peaks)]));subset.append(trial)
 best[s]=max(subset,key=lambda t:(t['case_macro_f1'],t['case_macro_recall'],t['config']['threshold'],t['config']['min_distance']));trials.extend(subset)
 print(json.dumps(dict(sigma=s,F1=best[s]['case_macro_f1'],tumor=best[s]['tumor_recalls'],counts=best[s]['localization'])),flush=True)
a=best[0];eligible=[s for s,b in best.items() if s and b['case_macro_f1']-a['case_macro_f1']>=.03-1e-12 and b['tumor_recalls'][0]>=a['tumor_recalls'][0]]
selected=max(eligible,key=lambda s:(best[s]['case_macro_f1'],best[s]['case_macro_recall'],-s)) if eligible else None
result=dict(selected_sigma=selected,best_by_sigma=best,trials=trials,seconds=time.perf_counter()-start,train_images=len(rows),heldout_inference_images=0)
(dest/'result.json').write_text(json.dumps(result,indent=2)+'\n');print('SELECTED',selected,flush=True)
