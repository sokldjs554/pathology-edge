"""Export full categorical tuples after the frozen run; no inference."""
import argparse,csv,json,hashlib
from pathlib import Path
import numpy as np
from PIL import Image
from scipy.ndimage import zoom
p=argparse.ArgumentParser();p.add_argument('--base',type=Path,required=True);p.add_argument('--supplement',type=Path,required=True);a=p.parse_args();b=a.base;s=a.supplement
protocol=s/'evaluation/protocol.json';data=json.loads(protocol.read_text());out=s/'aligned_masks';out.mkdir(exist_ok=False);rows=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for item in data['images']:
 raw=b/'raw/mask'/(item['id']+'.png');mask=np.array(Image.open(raw));w,h=item['grid']['target_wh'];mw,mh=item['grid']['source_wh'];aligned=zoom(mask,(h/mh,w/mw,1),order=0,grid_mode=True,prefilter=False,mode='nearest');path=out/(item['key']+'.png');Image.fromarray(aligned).save(path)
 rows.append(dict(key=item['key'],id=item['id'],path=path.relative_to(s).as_posix(),sha256=sha(path),raw_path=raw.relative_to(b).as_posix(),raw_sha256=sha(raw),source_wh=[mw,mh],target_wh=[w,h],identity=item['grid']['identity'],level0_bounds=item['level0_bounds'],display_annotations=item['display_annotations']))
(s/'aligned-mask-manifest.json').write_text(json.dumps(dict(protocol_sha256=sha(protocol),scope='Post-run deterministic categorical exports; model inference not run',rows=rows),indent=2))
with (s/'grid-map.csv').open('w',newline='') as f:
 writer=csv.writer(f);writer.writerow(['key','case_id','source_mask_w','source_mask_h','rgb_w','rgb_h','level0_left','level0_top','level0_right','level0_bottom','identity','id'])
 for item in data['images']:writer.writerow([item['key'],item['case_id'],*item['grid']['source_wh'],*item['grid']['target_wh'],*item['level0_bounds'],item['grid']['identity'],item['id']])
print(json.dumps(dict(exported_masks=len(rows),transformed=sum(not r['identity'] for r in rows))))
