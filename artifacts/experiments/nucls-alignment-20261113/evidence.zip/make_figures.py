"""Derived diagnostic figures; no inference or label editing."""
from pathlib import Path
import json,hashlib
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from scipy.ndimage import binary_erosion,zoom
import argparse
parser=argparse.ArgumentParser();parser.add_argument('--base',type=Path,required=True);parser.add_argument('--supplement',type=Path,required=True);a=parser.parse_args();B=a.base;S=a.supplement;O=S/'evaluation';D=S/'figures';D.mkdir(exist_ok=True)
p=json.loads((O/'protocol.json').read_text());r=json.loads((O/'results.json').read_text());rows={x['id']:x for x in r['rows']}
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
f=ImageFont.truetype(font,16);small=ImageFont.truetype(font,13);title=ImageFont.truetype(font,22)
def load(item):
 rgb=np.array(Image.open(B/item['input']).convert('RGB'))
 with np.load(O/item['label']) as z:t,v=z['target'],z['valid']
 return rgb,t,v

def overlay(rgb,t,v):
 out=rgb.astype(float);out[~v]*=.28;edge=t&~binary_erosion(t);out[edge&v]=[30,230,205]
 return Image.fromarray(out.astype('uint8'))

def fit(im,size):
 canvas=Image.new('RGB',size,'#eef1f4');im=im.copy();im.thumbnail(size,Image.Resampling.BILINEAR);canvas.paste(im,((size[0]-im.width)//2,(size[1]-im.height)//2));return canvas

new=[x for x in p['images'] if not x['grid']['identity']]
index=[]
for page in range(3):
 canvas=Image.new('RGB',(1320,1120),'#f7f8fa');draw=ImageDraw.Draw(canvas)
 draw.text((20,12),f'NuCLS SP.3 / normalized36 / sheet {page+1} of3',font=title,fill='#162b38')
 draw.text((20,44),'Left: fixed original RGB | Right: normalized outline (cyan); excluded pixels dimmed',font=f,fill='#243b47')
 for j,item in enumerate(new[page*12:(page+1)*12]):
  rgb,t,v=load(item);x=(j%3)*440;y=80+(j//3)*255
  src=item['grid']['source_wh'];dst=item['grid']['target_wh']
  draw.text((x+8,y),f"#{item['key']} {item['case_id']}",font=f,fill='#162b38')
  draw.text((x+8,y+22),f"mask {src[0]}x{src[1]} -> RGB {dst[0]}x{dst[1]}",font=small,fill='#243b47')
  canvas.paste(fit(Image.fromarray(rgb),(210,200)),(x+8,y+43));canvas.paste(fit(overlay(rgb,t,v),(210,200)),(x+222,y+43))
 filename=f'normalized36-sheet-{page+1}.png';canvas.save(D/filename,optimize=True);index.append(dict(file=filename,keys=[x['key'] for x in new[page*12:(page+1)*12]]))
# Deterministic known half-pixel tie example, chosen by geometry before metric inspection.
item=next(x for x in new if x['grid']['source_wh'][0]==404 and x['grid']['target_wh'][0]==403)
rgb,t,v=load(item);mask=np.array(Image.open(B/'raw/mask'/(item['id']+'.png')));codes=mask[...,0]
raw=np.zeros_like(mask);raw[codes==253]=[216,222,228];raw[(codes>=1)&(codes<=12)]=[30,180,160];raw[codes==99]=[215,156,54]
canvas=Image.new('RGB',(1500,650),'#f7f8fa');draw=ImageDraw.Draw(canvas);draw.text((20,12),f"Grid normalization / #{item['key']} {item['case_id']}",font=title,fill='#162b38')
draw.text((20,46),'Same level0 ROI extent; no image registration or model tuning. Masks use nearest-neighbor categorical sampling.',font=f,fill='#243b47')
images=[Image.fromarray(rgb),Image.fromarray(raw),overlay(rgb,t,v)]
src=item['grid']['source_wh'];dst=item['grid']['target_wh']
labels=[f'Original RGB / {dst[0]} x {dst[1]}',f'Raw categorical mask / {src[0]} x {src[1]}',f'Normalized overlay / {dst[0]} x {dst[1]}']
for j,(im,label) in enumerate(zip(images,labels)):
 x=10+j*500;draw.text((x+8,85),label,font=f,fill='#162b38');canvas.paste(fit(im,(480,480)),(x+4,115))
draw.text((20,611),'Cyan: nuclear boundary; dim overlay: not evaluated. Display panels scaled to fit; native pixel dimensions shown above.',font=f,fill='#243b47')
canvas.save(D/'alignment-example.png',optimize=True)
example=dict(key=item['key'],id=item['id'],case_id=item['case_id'],grid=item['grid'],level0_bounds=item['level0_bounds'],choice='Known404-to403 floating half-pixel tie; geometry chosen, not performance cherry-pick')
# All51 largest per-FOV decline, fixed rule; stored probabilities only.
def delta(it):
 m=rows[it['id']]['models'];return m['small_vit_refined']['metrics']['all']['dice']-m['small_vit']['metrics']['all']['dice']
item=min(p['images'],key=delta);rgb,t,v=load(item);row=rows[item['id']];panels=[Image.fromarray(rgb),overlay(rgb,t,v)];labels=['Original RGB','Aligned reference / cyan outline']
for arch in p['models']:
 m=row['models'][arch];ref=m['probability'];root=B if ref['root']=='base' else O
 with np.load(root/ref['path']) as z:pred=z['probability']>=.35
 pic=rgb.astype(float)*.55;pic[~v]*=.35;pic[v&t&pred]=[30,220,190];pic[v&~t&pred]=[230,80,135];pic[v&t&~pred]=[65,145,255];panels.append(Image.fromarray(pic.astype('uint8')));labels.append(f"{arch} / Dice {m['metrics']['all']['dice']:.6f}")
canvas=Image.new('RGB',(1800,630),'#f7f8fa');draw=ImageDraw.Draw(canvas);draw.text((20,12),f"Largest decline among51 / #{item['key']} {item['case_id']}",font=title,fill='#162b38');draw.text((20,48),'Identical coordinates in every panel. Evaluated support only; no whole-WSI or clinical validation.',font=f,fill='#243b47')
for j,(im,label) in enumerate(zip(panels,labels)):
 x=10+j*450;draw.text((x,90),label,font=f,fill='#162b38');canvas.paste(fit(im,(435,450)),(x,120))
draw.text((20,590),'Cyan: TP / pink: false positive / blue: missed foreground / dim: excluded. Pixel counts are not nucleus counts.',font=f,fill='#243b47');canvas.save(D/'largest-decrease51.png',optimize=True)
metadata=dict(contact_sheets=index,alignment_example=example,largest_decrease=dict(key=item['key'],id=item['id'],case_id=item['case_id'],level0_bounds=item['level0_bounds'],delta=delta(item),models={a:row['models'][a]['metrics']['all'] for a in p['models']}),figures={x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in D.glob('*.png')})
(D/'manifest.json').write_text(json.dumps(metadata,indent=2))
print(json.dumps(dict(figures=len(metadata['figures']),example_key=example['key'],largest_decrease=metadata['largest_decrease']),indent=2))
