NuCLS categorical-grid supplement / 2026-11-13 KST.
36 unequal grids normalized,15 identity grids retained;51 FOVs/five cases evaluated.
72 new original-crop inferences;30 old predictions reused. No training or tuning.
This is an explicit author-guided grid convention, NOT recovery of the historical
raw SP.3 exporter or proof of subpixel annotation accuracy. Partial annotated
support only; no clinical or exhaustive whole-WSI ground-truth validation.

This is NOT standalone. Extract the immutable base evidence in a separate folder:
https://raw.githubusercontent.com/sokldjs554/pathology-edge/f25bd6f52e55273ee3ede81418ac8dbe6db20448/artifacts/experiments/nucls-sp3-20261113/evidence.zip
SHA256 ae7b3ac863c02ddab9e1c6f52155465df7ebf366680f16e708fd7b0e798be9e8
Bytes 56975068. Base contains raw153 assets, original51 crops, weights, old probabilities.
This supplement contains new72 probability arrays, labels, transformed display
vertices, aligned categorical masks, grid map, frozen source, checks and figures.
Base and supplement must NOT be extracted on top of one another.

With pinned project dependencies (SciPy1.18.1 / NumPy2.5.4 / Pillow):
python audit_nucls_alignment.py --base ../nucls-base-audit --supplement .
This reads only, never loads a model or runs inference.
For fresh inference, use the repository scripts/run_nucls_alignment.py with a
new output directory. evaluation/runner.py is the frozen record of this run.
The figure/export scripts accept --base and --supplement. Do not rerun the export
script into this issued archive; its existing output guard intentionally fails.

REPORT.md is a report snapshot; its repository-relative links require browsing
https://github.com/sokldjs554/pathology-edge/blob/main/docs/NUCLS_GRID_ALIGNMENT.md
for navigation. Local figures/ and manifests provide the archived evidence.
NuCLS datasets:CC0 1.0; cite Amgad et al. https://arxiv.org/abs/2102.09099.
Original public SVS:GDC; exactUUIDs/MD5 in base evidence. Full5GBWSIs not included.
All new work executed in the provided development environment; user-authored
functions remain unchanged and this is not credited as new user execution.
