from pathlib import Path
import json,hashlib,shutil,zipfile
B=Path(__file__).resolve().parent;repo=B.parents[1];D=repo/'artifacts/experiments/nucls-sp3-20261113';D.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
selected=['annotation-acquisition.json','original-acquisition.json','source-files.json','support-audit.json','independent-audit.json','selected-examples.json','codes.csv','acquire_annotations.py','acquire_originals.py','probe_sources.py','support.py','test_support.py','run_evaluation.py','audit_results.py','inspect_linkage.py','make_figures.py','package_evidence.py','original-acquisition.log','evaluation.log','tests-red.log','tests-green.log','regression-tests.log','linkage-contact-sheet.png','largest-decrease.png','largest-increase.png','csv-complete-listing.json','mask-complete-listing.json','rgb-complete-listing.json']
files=[B/f for f in selected]
for name in ['raw','originals','evaluation']:
 files += [p for p in (B/name).rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts]
for path in files:
 if not path.is_file():raise ValueError(path)
manifest={str(p.relative_to(B)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(files)}
(B/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2))
readme='''NuCLS SP.3 linked annotated-support evaluation, 2026-11-13 KST.
51 RGB/CSV/mask triplets acquired;36 shape-mismatched pairs quarantined BEFORE inference.
15 FOVs/four case groups evaluated with frozen models, original and supplied RGB.
Five original SVS streams were verified against GDC MD5; full5GB files are NOT included.
Original crop byte ranges/metadata/hash records are in original-acquisition.json.
No training, threshold tuning, clinical validation or whole-WSI ground-truth validation.
A0SP overlaps a previously evaluated external patient; not four new independent patients.

Extract into a fresh directory. With project Python dependencies installed:
python audit_results.py .
The audit reads stored files only; no model loading, inference or training.
python -m pytest -q test_support.py
Do not run the archived worker inside an existing result directory: it is the original research runner, not a transactional rerun CLI.
The original acquisition scripts need requests,tifffile,imagecodecs,numpy,Pillow and the archived evaluation/source on PYTHONPATH.
probe_sources.py records the historical metadata-query script and depends on the project's earlier public slide catalogue; source-files.json preserves its complete selected outputs.

Published NuCLS datasets license: CC0 1.0; cite Amgad et al., NuCLS, https://arxiv.org/abs/2102.09099.
Official manual annotation description: https://sites.google.com/view/nucls/multi-rater
Format: https://sites.google.com/view/nucls/data-format
Original WSIs: https://portal.gdc.cancer.gov/ (exact public UUIDs recorded).
The project model/pipeline sources are preserved under evaluation/source; user-authored LocalResidualHead is unchanged.
All acquisition/this experiment/audit were run in the provided development environment, not reported as new user executions.
'''
(B/'README.txt').write_text(readme)
archive=D/'evidence.zip'
if archive.exists():raise FileExistsError('Do not overwrite issued evidence')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files+[B/'evidence-manifest.json',B/'README.txt']:z.write(p,p.relative_to(B).as_posix())
 z.write(repo/'docs/NUCLS_SP3_EVALUATION.md','REPORT.md')
with zipfile.ZipFile(archive) as z:
 if z.testzip() is not None:raise ValueError('CRC failure')
 for name,record in manifest.items():
  body=z.read(name)
  if len(body)!=record['bytes'] or hashlib.sha256(body).hexdigest()!=record['sha256']:raise ValueError('Archive payload mismatch')
 count=len(z.namelist())
for name in ['annotation-acquisition.json','original-acquisition.json','source-files.json','support-audit.json','independent-audit.json','selected-examples.json','tests-green.log','regression-tests.log','linkage-contact-sheet.png','largest-decrease.png','largest-increase.png','README.txt']:
 shutil.copy2(B/name,D/name)
for name in ['protocol.json','results.json','status.json']:shutil.copy2(B/'evaluation'/name,D/name)
shutil.copy2(B/'evidence-manifest.json',D/'file-manifest.json')
info=dict(bytes=archive.stat().st_size,sha256=sha(archive),members=count,manifest_files_checked=len(manifest),crc_passed=True,all_member_hashes_match=True,whole_wsi_files_included=False,report_source_commit=json.loads((B/'evaluation/protocol.json').read_text())['source_commit'])
(D/'archive.json').write_text(json.dumps(info,indent=2));print(json.dumps(info))
