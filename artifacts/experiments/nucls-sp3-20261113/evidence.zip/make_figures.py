from pathlib import Path
import json
import numpy as np
from PIL import Image,ImageDraw,ImageFont
B=Path(__file__).resolve().parent;O=B/'evaluation'
r=json.loads((O/'results.json').read_text());p=json.loads((O/'protocol.json').read_text());items={x['id']:x for x in p['images']}
def delta(row):
 a=row['inputs']['original'];return a['small_vit_refined']['metrics']['all']['dice']-a['small_vit']['metrics']['all']['dice']
selected={'largest-decrease':min(r['rows'],key=delta),'largest-increase':max(r['rows'],key=delta)}
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',14)
fontbig=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',18)
for label,row in selected.items():
 item=items[row['id']];image=np.asarray(Image.open(O/item['inputs']['original']['path']).convert('RGB'))
 with np.load(O/item['label'],allow_pickle=False) as z:t,v=z['target'],z['valid']
 gt=image.copy();gt[~v]=(gt[~v]*.18).astype('uint8');gt[t&v]=(gt[t&v]*.3+np.array([0,190,160])*.7).astype('uint8')
 panels=[('Original WSI crop',image,'Same coordinates in every panel'),('Manual GT / valid support',gt,'Dark = ignored; teal = annotated foreground')]
 for arch,title in [('small_vit','Baseline'),('small_vit_refined','Residual refinement')]:
  m=row['inputs']['original'][arch];score=m['metrics']['all']
  with np.load(O/m['probability'],allow_pickle=False) as z:pred=z['probability']>=.35
  out=image.copy();out[~v]=(out[~v]*.18).astype('uint8')
  for selection,color in [(v&t&pred,[0,190,160]),(v&~t&pred,[239,70,139]),(v&t&~pred,[60,130,245])]:out[selection]=(out[selection]*.2+np.array(color)*.8).astype('uint8')
  panels.append((title,out,f"Dice {score['dice']:.6f} | FP {score['fp']:,} | FN {score['fn']:,}"))
 canvas=Image.new('RGB',(1600,580),(247,249,250));d=ImageDraw.Draw(canvas)
 d.text((12,12),f"{label} | {row['case_id']} | refined - baseline Dice {delta(row):+.6f}",font=fontbig,fill=(25,35,45))
 for i,(title,a,caption) in enumerate(panels):
  im=Image.fromarray(a);im.thumbnail((390,410));canvas.paste(im,(i*400+5,95))
  d.text((i*400+8,60),title,font=fontbig,fill=(25,35,45));d.text((i*400+8,515),caption,font=font,fill=(25,35,45))
 d.text((12,548),'Teal: true positive / GT. Pink: false positive. Blue: missed foreground. Dark: not scored. Pixel segmentation, not cell counts.',font=font,fill=(25,35,45))
 canvas.save(B/(label+'.png'))
summary={name:dict(id=row['id'],key=row['key'],delta=delta(row),baseline=row['inputs']['original']['small_vit']['metrics']['all'],refined=row['inputs']['original']['small_vit_refined']['metrics']['all']) for name,row in selected.items()}
(B/'selected-examples.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
print('provided',r['summary']['provided']['all']['fov_macro'])
print('mask_only',r['summary']['original']['mask_only_support']['fov_macro'])
