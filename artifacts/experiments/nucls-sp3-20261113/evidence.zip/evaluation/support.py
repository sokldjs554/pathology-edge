"""NuCLS explicit annotated support, not exhaustive WSI/FOV coverage.

Mask class 253 is explicitly annotated background. Zero is unannotated and 99
is unlabeled. Named nuclear structures use 1..12. CSV rectangles are excluded;
CSV/published-mask contour disagreements are ignored in the primary analysis.
"""
import math
import numpy as np
from PIL import Image, ImageDraw

CLASSES={'tumor':1,'fibroblast':2,'lymphocyte':3,'plasma_cell':4,
 'macrophage':5,'mitotic_figure':6,'vascular_endothelium':7,'myoepithelium':8,
 'apoptotic_body':9,'neutrophil':10,'ductal_epithelium':11,'eosinophil':12,'unlabeled':99}

def annotation_support(mask, rows):
 if (not isinstance(mask,np.ndarray) or mask.dtype!=np.uint8 or mask.ndim!=3
     or mask.shape[2]!=3 or not mask.size):raise ValueError('Nonempty uint8 HWC mask required')
 codes=mask[...,0];h,w=codes.shape
 if not np.isin(codes,[0,99,253,*range(1,13)]).all():raise ValueError('Unknown mask class code')
 nuclei=Image.new('1',(w,h));unknown=Image.new('1',(w,h));boxes=Image.new('1',(w,h))
 known_draw,unknown_draw,box_draw=map(ImageDraw.Draw,(nuclei,unknown,boxes))
 nr=np_=nu=0
 for r in rows:
  if r.get('type') not in ('polyline','rectangle') or r.get('raw_classification') not in CLASSES:
   raise ValueError('Unknown annotation type or class')
  try:
   box=[float(r[k]) for k in ('xmin','ymin','xmax','ymax')]
   if any(not math.isfinite(v) or v!=int(v) or abs(v)>=2**30 for v in box) or box[0]>=box[2] or box[1]>=box[3]:raise ValueError
   box=list(map(int,box))
  except (KeyError,TypeError,ValueError,OverflowError) as e:raise ValueError('Finite integer bounds required') from e
  if r['type']=='rectangle':
   box_draw.rectangle(box,fill=1);nr+=1;continue
  try:
   x=[float(v) for v in r['coords_x'].split(',')];y=[float(v) for v in r['coords_y'].split(',')]
   if len(x)!=len(y) or len(x)<3 or any(not math.isfinite(v) or v!=int(v) or abs(v)>=2**30 for v in x+y):raise ValueError
  except (KeyError,TypeError,ValueError,AttributeError) as e:raise ValueError('Finite paired integer polygon coordinates required') from e
  points=list(zip(map(int,x),map(int,y)));np_+=1
  if r['raw_classification']=='unlabeled':unknown_draw.polygon(points,fill=1,outline=1);nu+=1
  else:known_draw.polygon(points,fill=1,outline=1)
 target=(codes>=1)&(codes<=12)
 base=(target|(codes==253))&~np.asarray(boxes,dtype=bool)&~np.asarray(unknown,dtype=bool)
 contours=np.asarray(nuclei,dtype=bool)
 unsupported=base&target&~contours;contradiction=base&~target&contours
 valid=base&~(unsupported|contradiction)
 if not valid.any():raise ValueError('No evaluable annotation pixels')
 stats=dict(image_pixels=h*w,explicit_background_pixels=int((codes==253).sum()),unannotated_pixels=int((codes==0).sum()),unlabeled_mask_pixels=int((codes==99).sum()),polyline_rows=np_,rectangle_rows=nr,unlabeled_polyline_rows=nu,excluded_rectangle_pixels=int(np.asarray(boxes,dtype=bool).sum()),base_valid_pixels=int(base.sum()),valid_pixels=int(valid.sum()),foreground_valid_pixels=int((target&valid).sum()),valid_fraction=float(valid.mean()),unsupported_foreground_pixels=int(unsupported.sum()),contradictory_background_pixels=int(contradiction.sum()))
 return target,valid,base,stats
