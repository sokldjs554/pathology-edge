import numpy as np
import pytest
from support import annotation_support

def row(kind='polyline',label='tumor',xs='1,2,2,1',ys='1,1,2,2'):
 return dict(type=kind,raw_classification=label,xmin='1',ymin='1',xmax='2',ymax='2',coords_x=xs,coords_y=ys)
def fixture():
 m=np.full((5,5,3),253,np.uint8);m[1:3,1:3,0]=1;return m

def test_explicit_background_and_foreground_only():
 m=fixture();m[0,0,0]=0;m[0,1,0]=99
 t,v,base,s=annotation_support(m,[row()])
 assert t.sum()==4 and v.sum()==23 and np.array_equal(v,base)
 assert not v[0,0] and not v[0,1] and v[4,4]

def test_rectangle_excluded_inclusive():
 t,v,base,s=annotation_support(fixture(),[row('rectangle')])
 assert v.sum()==21 and not v[1:3,1:3].any() and s['rectangle_rows']==1

def test_disagreement_excluded_both_directions():
 m=fixture();m[1,1,0]=253;m[4,4,0]=1
 t,v,base,s=annotation_support(m,[row()])
 assert base.sum()==25 and v.sum()==23
 assert s['unsupported_foreground_pixels']==1 and s['contradictory_background_pixels']==1

def test_unlabeled_contour_excluded_even_if_mask_background():
 m=fixture();m[1:3,1:3,0]=253
 t,v,base,s=annotation_support(m,[row(label='unlabeled')])
 assert v.sum()==21 and not v[1:3,1:3].any()

@pytest.mark.parametrize('bad',[13,98,254])
def test_unknown_mask_code_rejected(bad):
 m=fixture();m[0,0,0]=bad
 with pytest.raises(ValueError):annotation_support(m,[row()])

@pytest.mark.parametrize('bad',[dict(type='ellipse'),dict(raw_classification='unknown'),dict(coords_x='1,nan,2'),dict(coords_y='1,2'),dict(xmin='nan'),dict(coords_x='1.5,2,2,1')])
def test_invalid_annotation_rejected(bad):
 r=row();r.update(bad)
 with pytest.raises(ValueError):annotation_support(fixture(),[r])

def test_no_evaluable_pixels_rejected():
 with pytest.raises(ValueError):annotation_support(np.zeros((2,2,3),np.uint8),[])
