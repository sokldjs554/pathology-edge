"""Freeze and run a restricted NuCLS SP.3 annotated-support evaluation."""
from pathlib import Path
import argparse,csv,json,hashlib,shutil,sys,subprocess,os,re
from datetime import datetime,timezone
import numpy as np
from PIL import Image
from support import annotation_support
B=Path(__file__).resolve().parent
MODELS={'small_vit':'0bb2af67ca4d4e403e5789359feb6b284f9207e6c7eb9bf4e521b7d0972f5898','small_vit_refined':'b9d3892a257a06ed0b67bd4e8717a331d457272531b3501fadf1fbacd70f004f'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,o):Path(p).write_text(json.dumps(o,indent=2,ensure_ascii=False,allow_nan=False))
def freeze():
 out=B/'evaluation'
 if out.exists():raise FileExistsError('Use a fresh experiment directory')
 out.mkdir(); repo=B.parents[1]
 for d in ['inputs','labels','predictions','models','source/pathology_edge']:(out/d).mkdir(parents=True)
 for p in (repo/'src/pathology_edge').glob('*.py'):shutil.copy2(p,out/'source/pathology_edge'/p.name)
 for name in ['support.py','test_support.py','run_evaluation.py']:shutil.copy2(B/name,out/name)
 for arch,digest in MODELS.items():
  src=B.parent/'original-wsi-20261112/evaluation/models'/f'{arch}.pt'
  if sha(src)!=digest:raise ValueError('Fixed model changed')
  shutil.copy2(src,out/'models'/src.name)
 supports=json.loads((B/'support-audit.json').read_text());acq=json.loads((B/'original-acquisition.json').read_text())
 if len(supports)!=51 or len(acq['cases'])!=5 or any(not c['original_stream']['reference_md5_verified'] for c in acq['cases']):raise ValueError('Incomplete source audit')
 links={r['id']:r for c in acq['cases'] for r in c['rows']}
 images=[];excluded=[]
 for s in supports:
  name=s['id'];link=links[name]
  if not s['shapes_equal']:
   excluded.append(dict(id=name,reason='Published RGB/mask dimensions differ; no label resizing or inferred alignment',rgb_wh=s['rgb_wh'],mask_wh=s['mask_wh']));continue
  if link['rgb_correlation']<.99 or max(map(abs,link['phase_shift_xy']))>1:raise ValueError('Coordinate linkage inspection gate failed')
  key=f'{len(images):02d}';targets={}
  for source,path in [('original',B/link['original_path']),('provided',B/'raw/rgb'/(name+'.png'))]:
   filename=f'inputs/{key}-{source}.png';shutil.copy2(path,out/filename);targets[source]=dict(path=filename,sha256=sha(out/filename))
  mask=np.asarray(Image.open(B/'raw/mask'/(name+'.png')));rows=list(csv.DictReader((B/'raw/csv'/(name+'.csv')).open()))
  target,valid,base,stats=annotation_support(mask,rows)
  if mask.shape[:2]!=(s['rgb_wh'][1],s['rgb_wh'][0]):raise ValueError('RGB/mask mismatch')
  label=f'labels/{key}.npz';np.savez_compressed(out/label,target=target,valid=valid,base_valid=base)
  images.append(dict(key=key,id=name,case_id=link['case_id'],inputs=targets,label=label,label_sha256=sha(out/label),support=stats,linkage=link))
 if len(images)!=15 or len(excluded)!=36:raise ValueError('Prespecified technical subset differs')
 protocol=dict(created_utc=datetime.now(timezone.utc).isoformat(),source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),models=MODELS,threshold=.35,patch_size=128,mode='no_overlap',boundary_radius=8,selection='All51 SP.3 U-control FOVs acquired;15 equal-shape pairs pass;36 shape-mismatched pairs quarantined before inference',image_count=15,case_count=4,images=images,excluded=excluded,annotation_scope='Explicit background253 or named nuclear structure1..12; ignore0/99, inclusive rectangle extents, unlabeled CSV polygons; primary requires CSV/published-mask foreground agreement',annotation_limit='Intended FOV CSV not present in inspected folders; labeled nuclear extensions may be included. This is annotated-support scoring, not exhaustive FOV/WSI coverage.',primary_input='Original GDC level0 crop resized with Pillow BILINEAR to native supplied RGB dimensions (~0.2um/px)',secondary_input='Supplied RGB of the SAME FOVs, rendering sensitivity only',previous_external_patient_overlap=['TCGA-A1-A0SP'],new_cases_relative_to_previous_external=['TCGA-A7-A0DA','TCGA-AR-A1AR','TCGA-C8-A12V'],clinical_validation=False,whole_wsi_validation=False,external_training=False,threshold_tuning=False,source_sha256={p.name:sha(p) for p in sorted((out/'source/pathology_edge').glob('*.py'))},runner_sha256=sha(out/'run_evaluation.py'),support_sha256=sha(out/'support.py'),original_acquisition_sha256=sha(B/'original-acquisition.json'),annotation_acquisition_sha256=sha(B/'annotation-acquisition.json'),support_audit_sha256=sha(B/'support-audit.json'))
 save(out/'protocol.json',protocol)
 print(json.dumps(dict(frozen_protocol_sha256=sha(out/'protocol.json'),images=15,cases=4,excluded=36)),flush=True)
 return out

def worker(out):
 import torch,cv2
 from pathology_edge.model_comparison import build_model
 from pathology_edge.experiment import predict,environment
 from pathology_edge.metrics import binary_metrics
 from pathology_edge.patches import boundary_mask
 p=json.loads((out/'protocol.json').read_text())
 if p['models']!=MODELS or p['threshold']!=.35:raise ValueError('Protocol controls changed')
 if {q.name:sha(q) for q in (out/'source/pathology_edge').glob('*.py')}!=p['source_sha256'] or sha(out/'support.py')!=p['support_sha256']:raise ValueError('Frozen source changed')
 if sha(out/'run_evaluation.py')!=p['runner_sha256']:raise ValueError('Runner changed')
 torch.set_num_threads(4);cv2.setNumThreads(1);torch.use_deterministic_algorithms(True)
 models={}
 for arch,digest in MODELS.items():
  path=out/'models'/f'{arch}.pt'
  if sha(path)!=digest:raise ValueError('Checkpoint hash mismatch')
  model=build_model(arch);model.load_state_dict(torch.load(path,map_location='cpu',weights_only=True));models[arch]=model.eval()
 result=[]
 for item in p['images']:
  if sha(out/item['label'])!=item['label_sha256']:raise ValueError('Labels changed')
  with np.load(out/item['label'],allow_pickle=False) as l: target,valid,base=l['target'],l['valid'],l['base_valid']
  seams=boundary_mask(target.shape,size=128,radius=8);regions={'all':valid,'boundary':valid&seams,'interior':valid&~seams,'mask_only_support':base}
  row=dict(key=item['key'],id=item['id'],case_id=item['case_id'],inputs={})
  for source,asset in item['inputs'].items():
   if sha(out/asset['path'])!=asset['sha256']:raise ValueError('Input changed')
   image=np.asarray(Image.open(out/asset['path']).convert('RGB')).copy()
   if image.shape[:2]!=target.shape:raise ValueError('Input/label shape mismatch')
   row['inputs'][source]={}
   for arch,model in models.items():
    r=predict(model,image,mode='no_overlap',threshold=.35);prob=r['probability']
    if prob.shape!=target.shape or not np.isfinite(prob).all():raise ValueError('Invalid probability')
    filename=f"predictions/{item['key']}-{source}-{arch}.npz";np.savez_compressed(out/filename,probability=prob)
    row['inputs'][source][arch]=dict(probability=filename,sha256=sha(out/filename),metrics={name:binary_metrics(prob>=.35,target,reg) for name,reg in regions.items()},patch_count=r['patch_count'],skipped_background=r['skipped_background'],seconds_single_run=r['seconds'])
  result.append(row);print(json.dumps(dict(completed=len(result),case=item['case_id'])),flush=True)
 cases=sorted({r['case_id'] for r in result});summary={}
 for source in ['original','provided']:
  summary[source]={}
  for region in ['all','boundary','interior','mask_only_support']:
   case_means={case:{arch:float(np.mean([r['inputs'][source][arch]['metrics'][region]['dice'] for r in result if r['case_id']==case])) for arch in MODELS} for case in cases}
   fov_means={arch:float(np.mean([r['inputs'][source][arch]['metrics'][region]['dice'] for r in result])) for arch in MODELS}
   deltas=[r['inputs'][source]['small_vit_refined']['metrics'][region]['dice']-r['inputs'][source]['small_vit']['metrics'][region]['dice'] for r in result]
   summary[source][region]=dict(fov_macro=fov_means,fov_delta=fov_means['small_vit_refined']-fov_means['small_vit'],case_means=case_means,case_macro={arch:float(np.mean([case_means[c][arch] for c in cases])) for arch in MODELS},wins_ties_losses=[sum(d>0 for d in deltas),sum(d==0 for d in deltas),sum(d<0 for d in deltas)])
 report=dict(protocol_sha256=sha(out/'protocol.json'),rows=result,summary=summary,environment=environment(),inference_runs=len(result)*4,training_run=False,clinical_validation=False,whole_wsi_validation=False,timing_scope='Single descriptive pipeline execution per input/model, not a controlled benchmark')
 save(out/'results.json',report);save(out/'status.json',dict(completed=True,inference_runs=60,training_run=False))
 print(json.dumps(dict(primary=summary['original']['all'],boundary=summary['original']['boundary'],interior=summary['original']['interior'])),flush=True)

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--worker',type=Path);args=parser.parse_args()
 if args.worker:worker(args.worker.resolve())
 else:
  out=freeze();env=dict(os.environ,PYTHONPATH=str(out/'source'),PYTHONDONTWRITEBYTECODE='1')
  run=subprocess.run([sys.executable,str(out/'run_evaluation.py'),'--worker',str(out)],env=env)
  if run.returncode:save(out/'status.json',dict(completed=False,returncode=run.returncode))
  raise SystemExit(run.returncode)
