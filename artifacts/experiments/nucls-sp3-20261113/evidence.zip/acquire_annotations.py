from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import urllib.request, re, html, json, hashlib, time
BASE=Path(__file__).resolve().parent
FOLDERS={'root':'14vJDmJGbz2qaOLrE5aZftck9LYHPUuTK','csv':'1OF9Herx3aHH2HQ0RBt0ge4Pq7MFPIcvU','mask':'1SgHO9U-sJbL5TQPN7p5c0_BXKezbqOC9','rgb':'15_Mxl-4iBSFFmgBIfqw8Isq8g5xGsBA_'}
def fetch(url):
 for i in range(3):
  try:
   with urllib.request.urlopen(url,timeout=45) as r:
    if r.status!=200: raise ValueError(f'HTTP {r.status}')
    return r.read()
  except Exception:
   if i==2: raise
   time.sleep(1)
def listing(kind):
 p=BASE/f'{kind}-embedded.html'
 if not p.exists(): p.write_bytes(fetch(f'https://drive.google.com/embeddedfolderview?id={FOLDERS[kind]}'))
 rows=[{'id':a,'name':html.unescape(b)} for a,b in re.findall(r'<div class="flip-entry" id="entry-([^"<>]+)".*?<div class="flip-entry-title">([^<>]+)</div>',p.read_text(),re.S)]
 selected=[r for r in rows if r['name'].startswith('SP.3_#_U-control_#_') or r['name']=='all_fov_locations.csv']
 (BASE/f'{kind}-complete-listing.json').write_text(json.dumps(rows,indent=2))
 print(json.dumps({'kind':kind,'listed':len(rows),'selected':len(selected),'root_files':rows if kind=='root' else None}),flush=True)
 return kind,selected

def download(item):
 kind,row=item
 folder=BASE/'raw'/kind;folder.mkdir(parents=True,exist_ok=True)
 p=folder/row['name']
 if not p.exists(): p.write_bytes(fetch('https://drive.google.com/uc?export=download&id='+row['id']))
 b=p.read_bytes()
 if b.lstrip().startswith(b'<!DOCTYPE html'): raise ValueError('HTML response for '+row['name'])
 return dict(kind=kind,**row,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),path=str(p.relative_to(BASE)))
if __name__=='__main__':
 with ThreadPoolExecutor(max_workers=3) as pool: catalogs=list(pool.map(listing,FOLDERS))
 jobs=[(kind,r) for kind,rows in catalogs for r in rows]
 with ThreadPoolExecutor(max_workers=3) as pool:
  manifest=[]
  for row in pool.map(download,jobs):
   manifest.append(row)
   if len(manifest)%20==0: print(json.dumps({'acquired':len(manifest)}),flush=True)
 (BASE/'annotation-acquisition.json').write_text(json.dumps(manifest,indent=2))
 print(json.dumps({'files':len(manifest),'bytes':sum(r['bytes'] for r in manifest)}),flush=True)
