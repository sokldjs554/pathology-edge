"""Read-only independent arithmetic/hash audit; never load models or infer."""
from pathlib import Path
import json,hashlib,csv,sys,math
import numpy as np
from PIL import Image
from support import annotation_support
B=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent
O=B/'evaluation'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def eq(a,b,msg):
 if a!=b:raise ValueError(msg)
p=json.loads((O/'protocol.json').read_text());r=json.loads((O/'results.json').read_text())
eq(sha(O/'protocol.json'),r['protocol_sha256'],'protocol hash')
eq(p['threshold'],.35,'threshold');eq(p['image_count'],15,'count');eq(p['case_count'],4,'cases')
eq(len(p['excluded']),36,'quarantined');eq(len(r['rows']),15,'result rows')
eq(json.loads((O/'status.json').read_text())['completed'],True,'completion')
eq({x.name:sha(x) for x in (O/'source/pathology_edge').glob('*.py')},p['source_sha256'],'source')
eq(sha(O/'support.py'),p['support_sha256'],'support');eq(sha(O/'run_evaluation.py'),p['runner_sha256'],'runner')
for arch,s in p['models'].items():eq(sha(O/'models'/f'{arch}.pt'),s,'model')
for name,key in [('annotation-acquisition.json','annotation_acquisition_sha256'),('original-acquisition.json','original_acquisition_sha256'),('support-audit.json','support_audit_sha256')]:eq(sha(B/name),p[key],name)
for a in json.loads((B/'annotation-acquisition.json').read_text()):eq(sha(B/a['path']),a['sha256'],'raw asset')
acq=json.loads((B/'original-acquisition.json').read_text());eq(acq['files'],5,'original count');eq(acq['roi_count'],51,'source roi count')
for c in acq['cases']:
 eq(c['original_stream']['reference_md5_verified'],True,'original reference');eq(c['original_stream']['md5'],c['source']['md5sum'],'original md5')
 for x in c['rows']:eq(sha(B/x['original_path']),x['original_sha256'],'original crop')
checks=0;independent={}
for item,row in zip(p['images'],r['rows'],strict=True):
 eq(item['id'],row['id'],'row identity');eq(sha(O/item['label']),item['label_sha256'],'label')
 with np.load(O/item['label'],allow_pickle=False) as z:t,v,base=z['target'],z['valid'],z['base_valid']
 name=item['id'];mask=np.asarray(Image.open(B/'raw/mask'/(name+'.png')));anns=list(csv.DictReader((B/'raw/csv'/(name+'.csv')).open()))
 tt,vv,bb,stats=annotation_support(mask,anns)
 for a,b in [(t,tt),(v,vv),(base,bb)]:eq(np.array_equal(a,b),True,'label reconstruction')
 eq(stats,item['support'],'support stats')
 yy,xx=np.indices(t.shape);seams=np.zeros(t.shape,bool)
 for axis,length in [(xx,t.shape[1]),(yy,t.shape[0])]:
  for cut in range(128,length,128):seams|=((axis-cut)>=-8)&((axis-cut)<8)
 independent[row['key']]={}
 for source,asset in item['inputs'].items():
  eq(sha(O/asset['path']),asset['sha256'],'input');eq(Image.open(O/asset['path']).size,(t.shape[1],t.shape[0]),'shape')
  independent[row['key']][source]={}
  for arch,saved in row['inputs'][source].items():
   eq(sha(O/saved['probability']),saved['sha256'],'probability')
   with np.load(O/saved['probability'],allow_pickle=False) as z:probs=z['probability']
   eq(probs.shape,t.shape,'probability shape')
   if not np.isfinite(probs).all() or (probs<0).any() or (probs>1).any():raise ValueError('invalid probability')
   pred=probs>=.35;independent[row['key']][source][arch]={}
   for region,selection in [('all',v),('boundary',v&seams),('interior',v&~seams),('mask_only_support',base)]:
    truth=t[selection];prediction=pred[selection];inter=int(np.count_nonzero(truth&prediction));npred=int(np.count_nonzero(prediction));ngt=int(np.count_nonzero(truth));fp=npred-inter;fn=ngt-inter
    m=dict(tp=inter,fp=fp,fn=fn,pixels=int(selection.sum()),dice=2*inter/(npred+ngt) if npred+ngt else 1.,iou=inter/(inter+fp+fn) if inter+fp+fn else 1.,precision=inter/npred if npred else 0.,recall=inter/ngt if ngt else 0.)
    eq(m,saved['metrics'][region],'metric recount');independent[row['key']][source][arch][region]=m['dice'];checks+=1
aggregates=0
for source,groups in r['summary'].items():
 for region,summary in groups.items():
  means={arch:float(np.mean([independent[x['key']][source][arch][region] for x in r['rows']])) for arch in p['models']}
  eq(means,summary['fov_macro'],'FOV means');aggregates+=2
  bycase={c:{a:float(np.mean([independent[x['key']][source][a][region] for x in r['rows'] if x['case_id']==c])) for a in p['models']} for c in sorted({x['case_id'] for x in r['rows']})}
  eq(bycase,summary['case_means'],'case means');aggregates+=8
  eq({a:float(np.mean([bycase[c][a] for c in bycase])) for a in p['models']},summary['case_macro'],'case macro');aggregates+=2
  ds=[independent[x['key']][source]['small_vit_refined'][region]-independent[x['key']][source]['small_vit'][region] for x in r['rows']]
  eq([sum(d>0 for d in ds),sum(d==0 for d in ds),sum(d<0 for d in ds)],summary['wins_ties_losses'],'win counts')
  eq(means['small_vit_refined']-means['small_vit'],summary['fov_delta'],'delta')
print(json.dumps(dict(all_checks_passed=True,region_checks=checks,aggregate_mean_checks=aggregates,raw_assets=153,original_crops=51,evaluated_fovs=15,case_groups=4,excluded_shape_mismatch=36,original_stream_bytes=acq['total_original_bytes'],original_md5_matches=5,checkpoint_loading=False,inference_run=False,clinical_validation=False,whole_wsi_validation=False),indent=2))
