from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,re,hashlib,time,io
import requests,numpy as np,cv2,tifffile
from PIL import Image
from pathology_edge.wsi_source import RangeReader,decode_tiled_roi,verify_stream,validate_source_item
B=Path(__file__).resolve().parent
SOURCES=json.loads((B/'source-files.json').read_text())
ASSETS=json.loads((B/'annotation-acquisition.json').read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,o):p.write_text(json.dumps(o,indent=2,allow_nan=False))
def get(url,**kw):
 for i in range(3):
  r=requests.get(url,**kw)
  if r.status_code not in (429,502,503,504) or i==2:return r
  time.sleep(min(3,float(r.headers.get('Retry-After','1'))))
def acquire(item):
 case=item['case_id']; folder=B/'originals'/case;folder.mkdir(parents=True,exist_ok=True)
 if (folder/'audit.json').exists():return json.loads((folder/'audit.json').read_text())
 validate_source_item(item)
 file=item['gdc_matching'][0]; url='https://api.gdc.cancer.gov/data/'+file['file_id']
 reader=RangeReader(url,file['file_size'],get=get,block_size=1024*1024,allow_unitless_range=True)
 rows=[]
 with tifffile.TiffFile(reader) as slide:
  page=slide.pages[0]; mpp=float(re.search(r'\|MPP\s*=\s*([0-9.]+)',page.description).group(1))
  orientation=page.tags.get('Orientation')
  if orientation is not None and orientation.value!=1:raise ValueError('Nonstandard orientation')
  metadata=dict(size_wh=[page.imagewidth,page.imagelength],mpp=mpp,description_sha256=hashlib.sha256(page.description.encode()).hexdigest(),tile_wh=[page.tilewidth,page.tilelength],compression=int(page.compression))
  for a in sorted(ASSETS,key=lambda x:x['name']):
   if a['kind']!='rgb' or case not in a['name']:continue
   name=Path(a['name']).stem
   left,top,bottom,right=map(int,re.search(r'_left-(\d+)_top-(\d+)_bottom-(\d+)_right-(\d+)',name).groups())
   provided=np.asarray(Image.open(B/a['path']).convert('RGB'))
   h,w=provided.shape[:2];native,tiles=decode_tiled_roi(page,reader,(left,top,right,bottom))
   resized=Image.fromarray(native).resize((w,h),Image.Resampling.BILINEAR)
   p=folder/(name+'.png');resized.save(p);pixels=np.asarray(resized)
   shift,response=cv2.phaseCorrelate(cv2.cvtColor(provided,cv2.COLOR_RGB2GRAY).astype(np.float32),cv2.cvtColor(pixels,cv2.COLOR_RGB2GRAY).astype(np.float32))
   row=dict(id=name,case_id=case,bounds_level0=[left,top,right,bottom],output_wh=[w,h],effective_mpp_xy=[mpp*(right-left)/w,mpp*(bottom-top)/h],original_path=str(p.relative_to(B)),original_sha256=sha(p),provided_sha256=a['sha256'],decoded_tile_indices=tiles,rgb_correlation=float(np.corrcoef(provided.ravel(),pixels.ravel())[0,1]),rgb_mae=float(np.abs(provided.astype(float)-pixels).mean()),phase_shift_xy=shift,phase_response=response,registration_correction_applied=False)
   rows.append(row)
 save(folder/'roi-linkage.json',dict(source=file,metadata=metadata,rows=rows))
 print(json.dumps(dict(case=case,roi_count=len(rows),min_correlation=min(r['rgb_correlation'] for r in rows),max_shift=max(max(abs(x) for x in r['phase_shift_xy']) for r in rows))),flush=True)
 with get(url,headers={'Accept-Encoding':'identity'},stream=True,timeout=(15,60)) as r:
  r.raise_for_status()
  if r.status_code!=200:raise ValueError('Whole file HTTP response required')
  def chunks():
   total=0; next_=512*1024**2
   for chunk in r.iter_content(4*1024**2):
    total+=len(chunk)
    if total>=next_:
     print(json.dumps(dict(case=case,stream_MiB=total//1024**2)),flush=True);next_+=512*1024**2
    yield chunk
  audit=verify_stream(chunks(),file['file_size'],reader.blocks,file['md5sum'])
 result=dict(case_id=case,source=file,original_url=url,metadata=metadata,rows=rows,original_stream=audit,source_ranges=[dict(offset=o,bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for o,v in sorted(reader.blocks.items())],whole_file_retained=False,whole_slide_inference=False)
 save(folder/'audit.json',result)
 print(json.dumps(dict(case=case,md5_verified=audit['reference_md5_verified'])),flush=True)
 return result
if __name__=='__main__':
 with ThreadPoolExecutor(max_workers=2) as ex: rows=list(ex.map(acquire,SOURCES))
 save(B/'original-acquisition.json',dict(cases=rows,files=len(rows),roi_count=sum(len(r['rows']) for r in rows),total_original_bytes=sum(r['original_stream']['bytes'] for r in rows)))
