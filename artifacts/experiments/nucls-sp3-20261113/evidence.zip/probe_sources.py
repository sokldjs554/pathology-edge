from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import requests,json,re
b=Path(__file__).resolve().parent
items=json.loads((b.parent/'panoptils-20261112/dsa-items.json').read_text())
names=sorted({re.search(r'TCGA-[^_]+',r['name'])[0] for r in json.loads((b/'annotation-acquisition.json').read_text())})
def probe(name):
 ms=[r for r in items if r['name'].startswith(name+'.')]
 if len(ms)!=1: raise ValueError((name,len(ms)))
 item=ms[0];base='https://demo.kitware.com/histomicstk/api/v1/item/'+item['_id']
 def get(url,**kw):
  r=requests.get(url,timeout=40,**kw);r.raise_for_status();return r.json()
 filters={'op':'=','content':{'field':'file_name','value':item['name']}}
 hits=get('https://api.gdc.cancer.gov/files',params={'filters':json.dumps(filters),'fields':'file_id,file_name,file_size,md5sum,access,cases.submitter_id','size':10})['data']['hits']
 row=dict(slide_id=name,case_id='-'.join(name.split('-')[:3]),dsa_item_id=item['_id'],dsa_files=get(base+'/files'),tiles=get(base+'/tiles'),gdc_matching=hits)
 (b/(row['case_id']+'-source.json')).write_text(json.dumps(row,indent=2))
 print(json.dumps({'case':row['case_id'],'gdc':hits,'tiles':row['tiles']}),flush=True)
 return row
with ThreadPoolExecutor(max_workers=3) as ex: rows=list(ex.map(probe,names))
(b/'source-files.json').write_text(json.dumps(rows,indent=2))
