from pathlib import Path
import json,csv,re
import numpy as np
from PIL import Image,ImageDraw
from support import annotation_support
B=Path(__file__).resolve().parent
acq=json.loads((B/'original-acquisition.json').read_text());links={r['id']:r for c in acq['cases'] for r in c['rows']}
audit=json.loads((B/'support-audit.json').read_text());selected={}
for r in audit:
 if r['shapes_equal']:
  case=re.search(r'TCGA-[^-]+-[^-]+',r['id'])[0];selected.setdefault(case,r['id'])
canvas=Image.new('RGB',(1200,len(selected)*440),(246,247,248));d=ImageDraw.Draw(canvas)
for j,(case,name) in enumerate(selected.items()):
 orig=np.asarray(Image.open(B/links[name]['original_path']).convert('RGB'));provided=np.asarray(Image.open(B/'raw/rgb'/(name+'.png')).convert('RGB'))
 mask=np.asarray(Image.open(B/'raw/mask'/(name+'.png')));a=list(csv.DictReader((B/'raw/csv'/(name+'.csv')).open()));t,v,base,s=annotation_support(mask,a)
 over=orig.copy();over[~v]=(over[~v]*.2).astype('uint8');over[t&v]=(over[t&v]*.4+np.array([0,200,140])*.6).astype('uint8')
 for i,(title,img) in enumerate([('Direct original SVS',orig),('Supplied RGB',provided),('GT foreground; dark = ignored',over)]):
  im=Image.fromarray(img);im.thumbnail((390,380));canvas.paste(im,(i*400,j*440+45))
  d.text((i*400+6,j*440+8),case+' / '+title,fill=(20,30,40))
 d.text((5,j*440+420),name.split('_left-')[-1],fill=(20,30,40))
canvas.save(B/'linkage-contact-sheet.png')
print(json.dumps({'selected':selected,'new_inference_run':False}))
