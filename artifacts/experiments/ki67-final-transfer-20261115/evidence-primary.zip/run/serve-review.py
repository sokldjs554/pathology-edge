from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
ROOT=Path(__file__).resolve().parent
class Handler(BaseHTTPRequestHandler):
 def do_GET(self):
  if self.path not in ('/layout-fixture.html','/review.html'):
   self.send_error(404);return
  p=ROOT/self.path.lstrip('/')
  if not p.is_file():self.send_error(404);return
  raw=p.read_bytes();self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
 def log_message(self,*args):pass
ThreadingHTTPServer(('127.0.0.1',8878),Handler).serve_forever()
