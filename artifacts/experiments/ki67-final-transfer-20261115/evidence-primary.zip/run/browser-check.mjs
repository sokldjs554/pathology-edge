import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const root=process.argv[2],port=process.argv[3]||'9233';
const target=await fetch(`http://127.0.0.1:${port}/json/new?about:blank`,{method:'PUT'}).then(r=>r.json());
const ws=new WebSocket(target.webSocketDebuggerUrl);await new Promise((r,j)=>{ws.addEventListener('open',r,{once:true});ws.addEventListener('error',j,{once:true})});
let sequence=0;const pending=new Map();ws.addEventListener('message',e=>{const m=JSON.parse(e.data);if(m.id){const p=pending.get(m.id);pending.delete(m.id);if(m.error)p.reject(new Error(JSON.stringify(m.error)));else p.resolve(m.result)}});
function send(method,params={}){return new Promise((resolve,reject)=>{const id=++sequence;pending.set(id,{resolve,reject});ws.send(JSON.stringify({id,method,params}))})}
async function evaluate(expression){const r=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw new Error(JSON.stringify(r.exceptionDetails));return r.result.value}
function check(condition,message){if(!condition)throw new Error(message)}
await send('Page.enable');await send('Runtime.enable');await send('Emulation.setDeviceMetricsOverride',{width:1440,height:1000,deviceScaleFactor:1,mobile:false});
await send('Page.navigate',{url:'http://127.0.0.1:8878/review.html'});
for(let i=0;i<100;i++){if(await evaluate("document.readyState==='complete'&&!!document.getElementById('Ametrics')?.textContent"))break;await new Promise(r=>setTimeout(r,100))}
const checks=[];
for(let example=0;example<6;example++)for(let seed=0;seed<3;seed++){
 const r=await evaluate(`(()=>{byId('example').value=${example};byId('seed').selectedIndex=${seed};byId('example').dispatchEvent(new Event('change'));const e=data.examples[${example}],s=byId('seed').value;return {example:e.index,seed:s,identity:byId('identity').textContent,images:['GT','A','B'].map(a=>byId(a).querySelector('image').getAttribute('href')===e.rgb),metrics:['A','B'].map(a=>({actual:byId(a+'metrics').textContent,score:e.seeds[s][a].scores,circles:byId(a).querySelectorAll('circle').length,pairs:e.seeds[s][a].pairs.length}))}})()`);
 check(r.images.every(Boolean),'Images not synchronized');check(r.identity.includes(r.seed),'Seed identity missing');
 for(const m of r.metrics){const s=m.score;check(m.circles===s.pred_cells,'Overlay point count differs');check(m.pairs===s.localization.tp,'Matching line/TP count differs');for(const [k,label] of [['tp','TP'],['fp','FP'],['fn','FN']])check(m.actual.includes(label+' '+s.localization[k]),'Displayed count differs');check(m.actual.includes(s.localization.f1.toFixed(3))&&m.actual.includes(s.two_class_macro_f1.toFixed(3)),'Displayed F1 differs')}
 const invariance=await evaluate(`(()=>{const before=['GT','A','B'].map(a=>byId(a+'metrics').textContent);byId('overlay').click();byId('reference').click();byId('links').click();const unchanged=before.every((t,i)=>t===byId(['GT','A','B'][i]+'metrics').textContent);const hidden=['GT','A','B'].every(a=>byId(a).querySelectorAll('circle').length===0);byId('overlay').click();byId('reference').click();byId('links').click();return {unchanged,hidden}})()`);
 check(invariance.unchanged&&invariance.hidden,'Overlay changed metrics or failed to hide');checks.push({example:r.example,seed:Number(r.seed),same_image:true,counts_match:true,overlay_metrics_invariant:true});
}
await evaluate("byId('example').value=0;byId('seed').selectedIndex=0;byId('example').dispatchEvent(new Event('change'))");
fs.mkdirSync(path.join(root,'screenshots'),{recursive:true});
async function capture(name,width,height,mobile){await send('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile});await new Promise(r=>setTimeout(r,500));const layout=await evaluate("({scrollWidth:document.documentElement.scrollWidth,clientWidth:document.documentElement.clientWidth,height:document.documentElement.scrollHeight,text:document.body.innerText})");check(layout.scrollWidth<=layout.clientWidth,'Horizontal overflow '+name);check(!/NaN|undefined/.test(layout.text),'Invalid display number');const shot=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:true,clip:{x:0,y:0,width,height:layout.height,scale:1}});fs.writeFileSync(path.join(root,'screenshots',name+'.png'),Buffer.from(shot.data,'base64'));return {name,width,height:layout.height,horizontal_overflow:false}}
const screenshots=[await capture('desktop',1440,1000,false),await capture('mobile',390,844,true)];
const version=await send('Browser.getVersion');const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const report={all_checks_passed:true,browser:version.product,review_sha256:sha(fs.readFileSync(path.join(root,'review.html'))),script_sha256:sha(fs.readFileSync(process.argv[1])),source:'Automated actual Chromium via CDP on localhost HTTP; managed browser file:// access unavailable; not user-performed',combinations:checks.length,checks,screenshots:screenshots.map(s=>({...s,sha256:sha(fs.readFileSync(path.join(root,'screenshots',s.name+'.png')))}))};
fs.writeFileSync(path.join(root,'browser-review.json'),JSON.stringify(report,null,2),{flag:'wx'});console.log(JSON.stringify({all_checks_passed:true,combinations:checks.length,screenshots}));ws.close();
