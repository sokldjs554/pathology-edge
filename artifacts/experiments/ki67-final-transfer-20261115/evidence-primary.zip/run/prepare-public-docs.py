"""Link completed experiment evidence without rewriting learner contribution history."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[2];RUN=Path(__file__).resolve().parent
s=json.loads((RUN/'final-summary.json').read_text());r=json.loads((ROOT/'artifacts/experiments/ki67-final-transfer-20261115/package-receipt.json').read_text())
if not s['all_steps_executed'] or not s['audit']['all_checks_passed']:raise RuntimeError('Completed audit required')
a=s['internal_adopted'];t=s['stages']['test']['passes'];b=s['stages']['bcdata']['passes'];e=s['stages']['deepliif']['passes']
link='artifacts/handoff/PathologyEdge-FinalTransfer-20261115.zip'
text=(RUN/'final-report.md').read_text()
text += '\n## 검토·증거 파일\n\n[작은 검토 ZIP](../'+link+') · [전체 증거와 해시](../artifacts/experiments/ki67-final-transfer-20261115/) · [데스크톱 캡처](../artifacts/experiments/ki67-final-transfer-20261115/screenshots/desktop.png) · [작은 화면 캡처](../artifacts/experiments/ki67-final-transfer-20261115/screenshots/mobile.png).\n\n이 실험은 별도 IHC 중심 검출기 비교다. 이전 H&E 보정 모듈의 MoNuSeg·NuCLS 외부 악화 결과를 바꾸거나 대체하지 않는다. 코드·결과는 `feat/auto-ki67`의 초안 PR #2에 보존하며 기존 공개 데모는 유지한다.\n'
(ROOT/'docs/KI67_FINAL_TRANSFER.md').write_text(text)
lead=f'**마지막 고정 실험 완료(2026-11-15 KST):** 실제 ImageNet 사전학습 특징과 무작위 고정 특징을 세 seed로 비교하고, 학습 케이스 균등 추출·실제 검출 중심의 자동 분류·고정 외부 평가를 완료했다. 내부 채택 {a}/3, 재사용 내부 test 종합 기준 {t}/3, 재사용 BCData133 기준 {b}/3, 새 DeepLIIF597 기준 {e}/3이다. 실행 완료와 성능 기준 통과를 구분하며, 추가 튜닝 없이 이번 시도로 종료한다. [전체 결과·검토 ZIP](KI67_FINAL_TRANSFER.md). 이번 자동 실행을 사용자 직접 수행으로 추가하지 않았으며 최신 확인 기록은 U106이다. 임상·전체 WSI 검증은 미실시이고 H&E 외부 악화 결과도 유지한다.'
for name in ['FINAL_PROGRESS.md','COWORK_HANDOFF.md']:
 p=ROOT/'docs'/name;old=p.read_text();title,rest=old.split('\n',1)
 rest=rest.replace('**최신 상태(2026-11-13 UTC):**','**이전 통합 상태(2026-11-13 UTC):**',1)
 p.write_text(title+'\n\n'+lead+'\n'+rest)
p=ROOT/'README.md';old=p.read_text();anchor='[자동 Ki-67 패치 실험]'
i=old.index(anchor)
line=f'[마지막 사전학습·외부 평가](docs/KI67_FINAL_TRANSFER.md): 실제 ImageNet 가중치/무작위 특징 × 세 seed 비교와 자동 분석 평가를 완료했습니다. 내부 채택 {a}/3, 재사용 내부 test 종합 기준 {t}/3, BCData 재평가 {b}/3, 새 DeepLIIF 597장 기준 {e}/3입니다. [검토 ZIP]({link})에서 실제 결과를 볼 수 있습니다. 기존 데모를 유지하며 이번 고정 시도로 성능 보완을 마무리합니다.\n\n'
p.write_text(old[:i]+line+old[i:])
p=ROOT/'docs/superpowers/plans/2026-11-15-ki67-final-transfer.md';old=p.read_text()
for line in old.splitlines():
 if line.startswith('- [ ]') and 'Publish report/evidence/receipt' not in line:old=old.replace(line,line.replace('- [ ]','- [x]',1))
p.write_text(old)
lines=['# Final fixed transfer evidence','',f'Internal adoption {a}/3; reused test criteria {t}/3; reused BCData criteria {b}/3; new DeepLIIF criteria {e}/3.','', 'The review ZIP contains six prespecified DeepLIIF examples, the final report and screenshots. Primary and random-control evidence are separated to keep each public Git file below100MiB.','', '|archive|bytes|SHA256|','|---|---:|---|']
for arow in r['archives']:
 name=Path(arow['file']).name;href=name if name!='PathologyEdge-FinalTransfer-20261115.zip' else '../../handoff/'+name
 lines.append(f"|[{name}]({href})|{arow['bytes']}|`{arow['sha256']}`|")
lines += ['', 'BCData raw RGB/HDF5 and individual cell-coordinate rows are withheld; aggregate metrics and excluded-file hashes remain. Original licensed data and prior paths are required to reproduce the full evaluation. See package-receipt.json and the report for exact scope.','', 'The actual browser checks used localhost HTTP because file:// is blocked in this managed browser. These are automated checks, not user-executed tests. Clinical validation and whole-WSI ground-truth validation were not performed. Public download verification is recorded separately in publication.json after upload.','']
(ROOT/'artifacts/experiments/ki67-final-transfer-20261115/README.md').write_text('\n'.join(lines))
print('Prepared report, README, handoff pointers and evidence index; contribution history unchanged.')
