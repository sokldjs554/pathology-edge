"""Post-hoc explanation only. Does not select models, alter gates or run inference."""
from pathlib import Path
import json,gzip
ROOT=Path(__file__).resolve().parent
protocol=json.loads((ROOT/'protocol.json').read_text())
selection=json.loads((ROOT/'selection.json').read_text())
def gates(t,a):
 b=t['localization'];r=a['localization'];floors=protocol['floors']
 return dict(fp_nonincrease=b['fp']<=r['fp'],fn_nonincrease=b['fn']<=r['fn'],one_strict=b['fp']<r['fp'] or b['fn']<r['fn'],log_case_recall_floor=t['case_macro_recall']>=floors['case_macro_recall'],log_positive_tumor_recall_floor=t['tumor_recalls'][0]>=floors['tumor_recalls'][0],log_negative_tumor_recall_floor=t['tumor_recalls'][1]>=floors['tumor_recalls'][1],each_case_recall_90pct_A=all(t['cases'][k]['recall']>=.9*v['recall'] for k,v in a['cases'].items()))
rows=[]
for m in selection['models']:
 folder=ROOT/f"{m['arm']}-seed{m['seed']}"
 trials=json.loads(gzip.decompress((folder/'trials.json.gz').read_bytes()))
 checks=[gates(t,m['baseline']) for h in trials for t in h['trials']]
 diagnostic=gates(m['evaluation_trial'],m['baseline'])
 count=sum(all(c.values()) for c in checks)
 assert (count>0)==(m['selected'] is not None)
 row=dict(arm=m['arm'],seed=m['seed'],trial_count=len(checks),all_gates_pass=count,individual_gate_pass_counts={k:sum(c[k] for c in checks) for k in diagnostic},diagnostic_gates=diagnostic,diagnostic_failed=[k for k,v in diagnostic.items() if not v])
 if m['arm']=='pretrained':
  test=json.loads((ROOT/'evaluation/test'/str(m['seed'])/'comparison.json').read_text())
  row['reused_test_detection_criteria']=test['detection_criteria'];row['reused_test_pipeline_criteria']=test['pipeline_criteria'];row['reused_test_passed']=test['passed']
 rows.append(row)
result=dict(scope='Post-hoc descriptive failure decomposition of the already locked selection; no new selection, thresholds or inference',floors_origin='Prior LoG validation reference, not the current A detector',rows=rows)
with (ROOT/'fixed-gate-explanation.json').open('x') as f:json.dump(result,f,indent=2)
for r in rows:
 if r['arm']=='pretrained':print(r['seed'],r['diagnostic_failed'],r['reused_test_detection_criteria'],r['reused_test_pipeline_criteria'])
