"""Resume verification after terminal reconnection; never rerun model inference."""
from pathlib import Path
import subprocess,time,urllib.request,json
ROOT=Path(__file__).resolve().parents[2];RUN=Path(__file__).resolve().parent
if not (RUN/'audit.json').exists():raise RuntimeError('Completed metric audit required')
steps=[]
def command(args,label):
 with (RUN/(label+'.log')).open('x') as f:
  r=subprocess.run(args,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
 steps.append(dict(step=label,exit_code=r.returncode))
 (RUN/'verification-recovery-steps.json').write_text(json.dumps(steps,indent=2)+'\n')
 if r.returncode:raise RuntimeError(label+' failed; inspect log')
command(['/workspace/work/venv/bin/python','scripts/build_ki67_transfer_review.py','--run',str(RUN),'--output',str(RUN/'review.html')],'build-review')
with urllib.request.urlopen('http://127.0.0.1:8878/review.html',timeout=5) as r:
 if r.status!=200:raise RuntimeError('Local review HTTP unavailable')
port='9233'
with (RUN/'chromium.log').open('x') as f:
 proc=subprocess.Popen(['/usr/bin/chromium','--headless','--no-sandbox','--disable-dev-shm-usage','--disable-background-networking','--disable-component-update','--no-first-run','--remote-debugging-port='+port,'--user-data-dir='+str(RUN/'browser-profile'),'about:blank'],stdout=f,stderr=subprocess.STDOUT)
 try:
  for _ in range(60):
   try:
    with urllib.request.urlopen('http://127.0.0.1:'+port+'/json/version',timeout=1) as r:r.read()
    break
   except Exception:time.sleep(.3)
  command(['node',str(RUN/'browser-check.mjs'),str(RUN),port],'browser-check')
 finally:
  proc.terminate()
  try:proc.wait(timeout=15)
  except subprocess.TimeoutExpired:proc.kill();proc.wait()
command(['/workspace/work/venv/bin/python','scripts/build_ki67_transfer_report.py','--run',str(RUN)],'build-report')
print('Actual browser checks and factual report complete; no new inference.',flush=True)
