from pathlib import Path
import subprocess,time,urllib.request,sys
p=Path(__file__).resolve().parent;label=sys.argv[1];port='9234'
with (p/('layout-chromium-'+label+'.log')).open('x') as f:
 proc=subprocess.Popen(['/usr/bin/chromium','--headless','--no-sandbox','--disable-dev-shm-usage','--disable-background-networking','--no-first-run','--remote-debugging-port='+port,'--user-data-dir='+str(p/'layout-browser-profile'),'about:blank'],stdout=f,stderr=subprocess.STDOUT)
 try:
  for _ in range(30):
   try:
    with urllib.request.urlopen('http://127.0.0.1:'+port+'/json/version',timeout=1) as r:r.read()
    break
   except Exception:time.sleep(.2)
  out=subprocess.check_output(['node',str(p/'layout-check.mjs'),str(p),port],text=True)
  (p/('layout-'+label+'.json')).write_text(out);print(out)
 finally:proc.terminate();proc.wait(timeout=15)
