"""Package audited final results; no BCData raw pixels or individual cell coordinates."""
from pathlib import Path
import hashlib,json,zipfile,subprocess,sys
ROOT=Path(__file__).resolve().parents[2]
RUN=Path(__file__).resolve().parent
ART=ROOT/'artifacts/experiments/ki67-final-transfer-20261115'
HAND=ROOT/'artifacts/handoff/PathologyEdge-FinalTransfer-20261115.zip'
sys.path.insert(0,str(ROOT/'src'))
from pathology_edge.ki67_transfer_evaluation import validate_audited
validate_audited(RUN)
final=json.loads((RUN/'final-summary.json').read_text())
assert final['all_steps_executed'] and not final['user_new_execution_or_review_claimed']
assert json.loads((RUN/'browser-review.json').read_text())['all_checks_passed']
ART.mkdir(parents=True,exist_ok=False);HAND.parent.mkdir(exist_ok=True)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def package(dest,files,extra):
 names=[n for n,p in files]
 if len(names)!=len(set(names)):raise ValueError('Duplicate archive name')
 manifest={n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in files}
 with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for n,p in files:z.write(p,n)
  z.writestr('MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
  z.writestr('PACKAGE.json',json.dumps(extra,ensure_ascii=False,indent=2))
 with zipfile.ZipFile(dest) as z:
  if z.testzip() is not None:raise ValueError('CRC failure')
  for n,m in manifest.items():
   if hashlib.sha256(z.read(n)).hexdigest()!=m['sha256']:raise ValueError('Archived bytes differ')
 if dest.stat().st_size>=100*1024**2:raise ValueError('GitHub file too large')
 return dict(file=str(dest.relative_to(ROOT)),bytes=dest.stat().st_size,sha256=sha(dest),members=len(manifest)+2,crc_and_members_verified=True)
primary=[];controls=[];excluded=[]
for p in sorted(RUN.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(RUN);s=str(rel)
 if any(x.endswith('browser-profile') or x=='__pycache__' for x in rel.parts):continue
 if rel.name.endswith(('.pyc','.zip')):continue
 if s.startswith('evaluation/bcdata/') and rel.name in ('A.json.gz','B.json.gz'):
  excluded.append(dict(path=s,sha256=sha(p),bytes=p.stat().st_size,reason='BCData individual cell coordinates withheld; aggregate scores and hashes retained'));continue
 if rel.name in ('package-receipt.json',):continue
 if rel.parts[0].startswith('random-seed') or (len(rel.parts)==1 and rel.name.startswith(('random-','audit-random-'))):controls.append(('run/'+s,p))
 else:primary.append(('run/'+s,p))
# Code and the small fixed inputs needed to identify the public prior checkpoints.
for p in sorted((ROOT/'src/pathology_edge').glob('*.py')):primary.append(('current_source/'+str(p.relative_to(ROOT)),p))
for p in sorted((ROOT/'scripts').glob('*ki67*.py')):primary.append(('current_source/'+str(p.relative_to(ROOT)),p))
for p in sorted((ROOT/'tests').glob('*transfer*.py')):primary.append(('current_source/'+str(p.relative_to(ROOT)),p))
for rel in ['docs/superpowers/specs/2026-11-15-ki67-final-transfer-design.md','docs/superpowers/plans/2026-11-15-ki67-final-transfer.md','third_party/torchvision-SQUEEZENET-LICENSE']:
 primary.append(('current_source/'+rel,ROOT/rel))
protocol=json.loads((RUN/'protocol.json').read_text())
for key,names in [('prior',['protocol.json','selection.json','selection-lock.json','detector-20261117.pt','detector-20261118.pt','detector-20261119.pt']),('parent',['protocol.json','selection-lock.json','source-manifest.json','split.json','model.json','cnn-20261113.pt','cnn-20261114.pt','cnn-20261115.pt'])]:
 for n in names:primary.append(('prior-inputs/'+key+'/'+n,Path(protocol[key])/n))
for n in ['prospective-external-protocol.json','prospective-external-protocol.sha256','deepliif-test-index.json']:
 primary.append(('prior-inputs/external-protocol/'+n,ROOT/'work/ki67-capacity-20261114'/n))
prep=ROOT/'work/ki67-transfer-prep'
for p in sorted(prep.iterdir()):
 if p.is_file() and p.suffix in ('.json','.txt'):primary.append(('official-weight-verification/'+p.name,p))
meta=dict(scope='Final fixed transfer experiment; all results, including failures',source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),excluded=excluded,external_raw_images='Only six prespecified CC BY4.0 DeepLIIF RGB examples and format investigation; no BCData raw data',reproduction_limit='Original datasets, prior paths and BCData annotations are required for full evaluation audit. Package contains genuine original path/hash locks; do not rewrite past locks to claim the same run.',clinical_validation=False,whole_wsi_validation=False,user_new_work_claimed=False)
receipts=[package(ART/'evidence-primary.zip',primary,{**meta,'random_control_evidence':'evidence-controls.zip'}),package(ART/'evidence-controls.zip',controls,{**meta,'primary_evidence':'evidence-primary.zip'})]
review=[('review.html',RUN/'review.html'),('READ_FIRST.md',RUN/'final-report.md')]
for n in ['final-summary.json','audit.json','browser-review.json','ci-source.json','reference-amendment.json','external-input-review/palette-normalization-summary.json','screenshots/desktop.png','screenshots/mobile.png']:
 review.append((n,RUN/n))
receipts.append(package(HAND,review,{**meta,'instructions':'Unzip and serve that folder with python3 -m http.server 8000 --bind 127.0.0.1, then open http://127.0.0.1:8000/review.html. The managed browser was verified over localhost HTTP, not file://. Stored predictions, no inference. Six fixed examples x three seeds. Full evidence in artifacts/experiments/ki67-final-transfer-20261115.'}))
for n in ['final-summary.json','audit.json','browser-review.json','ci-source.json','reference-amendment.json']:
 (ART/n).write_bytes((RUN/n).read_bytes())
(ART/'screenshots').mkdir()
for n in ['desktop.png','mobile.png']:(ART/'screenshots'/n).write_bytes((RUN/'screenshots'/n).read_bytes())
(ART/'package-receipt.json').write_text(json.dumps(dict(archives=receipts,excluded=excluded),ensure_ascii=False,indent=2)+'\n')
(RUN/'package-receipt.json').write_text(json.dumps(receipts,indent=2)+'\n')
print(json.dumps(receipts),flush=True)
