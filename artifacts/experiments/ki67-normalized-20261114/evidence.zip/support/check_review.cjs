const {chromium}=require('playwright');
const fs=require('fs'),crypto=require('crypto');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage']});
 const page=await browser.newPage({viewport:{width:1440,height:1050}}),errors=[],externalRequests=[];page.on('request',r=>{if(!r.url().startsWith('http://127.0.0.1:8862/')&&!r.url().startsWith('data:'))externalRequests.push(r.url())});page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://127.0.0.1:8862/index.html');
 const waitImage=()=>page.waitForFunction(()=>[...document.querySelectorAll('canvas')].length===2&&[...document.querySelectorAll('canvas')].every(c=>c.getContext('2d').getImageData(0,0,1,1).data[3]===255));
 await waitImage();const stored=await page.evaluate(()=>data);
 if(stored.examples.length!==6||stored.summary.length!==3||stored.ablation.length!==6)throw Error('Displayed population differs');
 const checks=[];
 for(let i=0;i<stored.examples.length;i++){
  await page.selectOption('#example',String(i));await waitImage();const e=stored.examples[i];
  if(!(await page.locator('#case').innerText()).includes(e.image))throw Error('Image identity differs');
  const text=await page.locator('.counts').allTextContents();
  for(let j=0;j<2;j++){
   const p=e.panels[j?'B':'A'],c=p.counts;
   if(p.points.length!==c.tp+c.fp||e.gt.length!==c.tp+c.fn||p.matched.length!==c.tp||p.missed.length!==c.fn)throw Error('Counts do not correspond to saved points');
   for(const expected of [`후보 ${p.points.length}`,`TP ${c.tp}`,`FP ${c.fp}`,`FN ${c.fn}`,c.f1.toFixed(4),c.recall.toFixed(4)])if(!text[j].includes(expected))throw Error('Displayed count differs: '+expected);
  }
  const before=await page.locator('.counts').allTextContents(),withOverlay=await page.locator('canvas').first().evaluate(c=>c.toDataURL());
  await page.uncheck('#overlay');await waitImage();const raw=await page.locator('canvas').first().evaluate(c=>c.toDataURL());
  const rawPanels=await page.locator('canvas').evaluateAll(cs=>cs.map(c=>c.toDataURL()));if(rawPanels[0]!==rawPanels[1])throw Error('A/B raw frames differ');
  if(raw===withOverlay||JSON.stringify(before)!==JSON.stringify(await page.locator('.counts').allTextContents()))throw Error('Overlay altered counts or failed to change image');
  await page.check('#overlay');await waitImage();checks.push({example:i,image:e.image,counts:true,overlay_only:true});
 }
 await page.selectOption('#example','0');await waitImage();await page.click('#next');await waitImage();if(await page.locator('#example').inputValue()!=='1')throw Error('Next navigation failed');await page.click('#prev');await waitImage();
 await page.screenshot({path:'work/ki67-capacity-20261114/review-desktop.png',fullPage:true});
 await page.setViewportSize({width:390,height:844});await waitImage();
 if(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1))throw Error('Mobile document horizontal clipping');
 await page.locator('#example').scrollIntoViewIfNeeded();await page.selectOption('#example','5');await waitImage();await page.uncheck('#overlay');await waitImage();await page.check('#overlay');await waitImage();await page.evaluate(()=>scrollTo(0,0));
 if(!await page.locator('.scroll').first().evaluate(e=>{e.scrollLeft=e.scrollWidth;const ok=e.scrollLeft>0;e.scrollLeft=0;return ok}))throw Error('Mobile metric table cannot scroll');
 await page.screenshot({path:'work/ki67-capacity-20261114/review-mobile.png',fullPage:true});
 if(externalRequests.length)throw Error('Unexpected external asset request');
 if(errors.length)throw Error(errors.join('\n'));
 const report={all_checks_passed:true,examples:checks,desktop:[1440,1050],mobile:[390,844],console_errors:errors,external_requests:externalRequests,same_raw_frames:true,mobile_table_scroll:true,static_saved_results:true,user_review_confirmed:false,html_sha256:crypto.createHash('sha256').update(fs.readFileSync('work/normalized-review-20261114/index.html')).digest('hex')};
 fs.writeFileSync('work/ki67-capacity-20261114/browser.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report));await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
