"""Posthoc explanation only: never changes eligibility, weights, or settings."""
from pathlib import Path
import json
from pathology_edge.ki67_normalized_experiment import checked
from pathology_edge.ki67_union_experiment import read_rows,FLOORS
root=Path('work/normalized-centers-20261114');checked(root,selected=True)
models=json.loads((root/'selection.json').read_text())['models'];report=[]
key=lambda t:(t['case_macro_f1'],t['case_macro_recall'],-t['epoch'],t['config']['threshold'],t['config']['min_distance'])
for m in models:
 a=m['baseline'];path=root/f"width{m['width']}-seed{m['seed']}";trials=[t for epoch in read_rows(path/'trials.json.gz') for t in epoch['trials']]
 assert len(trials)==864
 def gates(t):
  ac,bc=a['localization'],t['localization']
  return dict(joint_fp_fn=bc['fp']<=ac['fp'] and bc['fn']<=ac['fn'] and (bc['fp']<ac['fp'] or bc['fn']<ac['fn']),
   macro_recall=t['case_macro_recall']>=FLOORS['case_macro_recall'],positive_tumor_recall=t['tumor_recalls'][0]>=FLOORS['tumor_recalls'][0],negative_tumor_recall=t['tumor_recalls'][1]>=FLOORS['tumor_recalls'][1],every_case_recall=all(t['cases'][k]['recall']>=.9*v['recall'] for k,v in a['cases'].items()))
 outcomes=[gates(t) for t in trials];joint=[t for t,g in zip(trials,outcomes) if g['joint_fp_fn']]
 assert sum(all(g.values()) for g in outcomes)==m['feasible_trials']
 target=m['selected'] or m['diagnostic'];criteria=gates(target)
 report.append(dict(width=m['width'],seed=m['seed'],primary=m['width']==16,eligible=m['selected'] is not None,parameters=m['parameter_count'],A=a,B=target,
   B_role='selected' if m['selected'] else 'unadopted diagnostic',B_criteria=criteria,failed_criteria=[k for k,v in criteria.items() if not v],
   gate_counts={k:sum(g[k] for g in outcomes) for k in outcomes[0]},joint_only_count=len(joint),best_joint_only=max(joint,key=key) if joint else None,
   full_gate_count=m['feasible_trials'],training_selection_seconds=m['training_selection_seconds']))
result=dict(scope='Posthoc failure explanation on repeatedly used validation227/4cases; does not replace original selection rules or evaluate holdouts',floors=FLOORS,models=report)
(root/'failure-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
for r in report:
 print(json.dumps({k:r[k] for k in ('width','seed','eligible','joint_only_count','full_gate_count','failed_criteria')},ensure_ascii=False))
