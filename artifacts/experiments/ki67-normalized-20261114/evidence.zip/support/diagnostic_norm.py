"""Train-only diagnostic spike: four fixed examples, not generalization evidence."""
from pathlib import Path
import json,time,hashlib
import numpy as np
import torch
from pathology_edge.model import TinyUNet
from pathology_edge.ki67_centers import center_target,center_focal_loss,peak_candidates
from pathology_edge.ki67_union import retain_candidates
from pathology_edge.ki67_experiment import load_sample,verify_data
from pathology_edge.ki67_evaluation import match_points,count_metrics
root=Path('work/ki67-capacity-20261114/normalized');p=json.loads(Path('work/learned-centers-leaky-run-20261113/protocol.json').read_text());rows=[r for r in json.loads((Path(p['parent'])/'source-manifest.json').read_text()) if r['split']=='train'];verify_data(p['data_dir'],rows)
chosen=[];cases=set();oracle={d:np.zeros(3,dtype=np.int64) for d in (4,6,8)}
for r in rows:
 rgb,gt,gc=load_sample(p['data_dir'],r);target=center_target(gt,rgb.shape[:2]);peaks,scores=peak_candidates(target)
 assert int((target==1).sum())==len(gt)
 for d in oracle:
  q=retain_candidates(peaks,scores,.5,d)['points_xy'];n=len(match_points(q,gt,6));oracle[d]+=[n,len(q)-n,len(gt)-n]
 if len(chosen)<4 and r['case_id'] not in cases and len(gt)>=10:chosen.append((r,rgb,gt,target));cases.add(r['case_id'])
assert len(chosen)==4
x=torch.from_numpy(np.stack([v[1] for v in chosen]).transpose(0,3,1,2).copy()).float()/255
y=torch.from_numpy(np.stack([v[3] for v in chosen])[:,None])
# Verify the augmentation geometry independently against integer point transforms.
for k in range(4):
 for fh in (False,True):
  for fw in (False,True):
   for _,rgb,gt,target in chosen:
    t=torch.rot90(torch.from_numpy(target),k,(0,1));q=gt.copy();h,w=target.shape
    for _ in range(k):q=np.column_stack([q[:,1],w-1-q[:,0]]);h,w=w,h
    if fh:t=t.flip(0);q[:,1]=h-1-q[:,1]
    if fw:t=t.flip(1);q[:,0]=w-1-q[:,0]
    yy,xx=np.nonzero(t.numpy()==1);assert sorted(map(tuple,q))==sorted(zip(xx,yy))
protocol=dict(scope='Train-only normalization ablation, no held-out performance; matched init, loss and steps versus original diagnostic',normalization='GroupNorm groups=max(1,channels//4) before each LeakyReLU',seed=20261117,images=[v[0]['image'] for v in chosen],cases=[v[0]['case_id'] for v in chosen],gt_counts=[len(v[2]) for v in chosen],selection_rule='First training image with>=10 annotated centers in each of first4 qualifying cases',widths=[4,16],steps=300,optimizer='fresh Adam .001',batch=4,augmentation=False,loss='existing center_focal_loss',head_bias=-2.19,thresholds=[.01,.03,.05,.1,.2,.3,.5,.7],distances=[4,6,8],source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),oracle={str(d):count_metrics(*v) for d,v in oracle.items()},geometry_checks=64)
(root/'diagnostic-protocol.json').write_text(json.dumps(protocol,indent=2)+'\n');print(json.dumps(protocol),flush=True)
torch.set_num_threads(2);torch.use_deterministic_algorithms(True);results=[]
for width in protocol['widths']:
 torch.manual_seed(protocol['seed']);m=TinyUNet(width)
 for n in ('e1','e2','bottom','d2','d1'):
  block=getattr(m,n);c=block[0].out_channels
  setattr(m,n,torch.nn.Sequential(block[0],torch.nn.GroupNorm(max(1,c//4),c),torch.nn.LeakyReLU(.1),block[2],torch.nn.GroupNorm(max(1,c//4),c),torch.nn.LeakyReLU(.1)))
 torch.nn.init.constant_(m.head.bias,-2.19);opt=torch.optim.Adam(m.parameters(),lr=.001);history=[];start=time.perf_counter()
 for step in range(301):
  if step:
   opt.zero_grad(set_to_none=True);loss=center_focal_loss(m(x),y);loss.backward();opt.step();assert torch.isfinite(loss)
  if step%50==0:
   with torch.inference_mode():heat=torch.sigmoid(m(x)).numpy()[:,0];lossvalue=float(center_focal_loss(m(x),y))
   peaks=[peak_candidates(h) for h in heat];trials=[]
   for th in protocol['thresholds']:
    for d in protocol['distances']:
     cnt=np.zeros(3,dtype=np.int64)
     for v,(pt,sc) in zip(chosen,peaks):
      q=retain_candidates(pt,sc,th,d)['points_xy'];n=len(match_points(q,v[2],6));cnt+=[n,len(q)-n,len(v[2])-n]
     trials.append(dict(threshold=th,distance=d,**count_metrics(*cnt)))
   best=max(trials,key=lambda a:(a['f1'],a['recall'],a['threshold'],a['distance']));entry=dict(width=width,step=step,loss=lossvalue,best=best,seconds=time.perf_counter()-start);history.append(entry);print(json.dumps(entry),flush=True)
 torch.save(m.state_dict(),root/f'diagnostic-width{width}.pt');results.append(dict(width=width,parameters=sum(v.numel() for v in m.parameters()),history=history))
(root/'diagnostic-results.json').write_text(json.dumps(results,indent=2)+'\n')
